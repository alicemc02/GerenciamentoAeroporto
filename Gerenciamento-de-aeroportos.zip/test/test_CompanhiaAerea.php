<?php

// ===============================================================
//Inclusão das classes necessárias para testar a classe aeroporto.


  include_once("../global.php");
  include_once("../classes/class.CompanhiaAerea.php");


// ================================================================



  $companhiaTAM = new CompanhiaAerea("TAM", "GUO", "TAM DISTRB. LTDA" ,"81435185000169", "TM", 23.00 );

  print_r($companhiaTAM);

  print_r($companhiaTAM->GetSigla);

  print_r($companhiaTAM->GetNome);
?>