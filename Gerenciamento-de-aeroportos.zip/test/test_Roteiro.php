<?php

  include_once("../global.php");
  echo "--------------INICIALIZANDO SISTEMA DE GERENCIAMENTO DE AEROPORTO-----------------";
  echo "\n";
  $newAeroporto = new Aeroporto("CNF","Confins","Minas Gerais");
  //tenta acessar uma funcionalidade sem ter realizado login

  $companhiaTAM = new CompanhiaAerea("TAM", "GUO", "TAM DISTRB. LTDA","81435185000169", "TM", 20.00);
  //tenta acessar outra funcionalidade sem ter realizado login

  echo "\n";
  Usuario::fazLoginAdmin ("admin", "admin");
  echo "\n";
  //realiza login com um usuario previamente cadastrado. Login: admin, Senha: admin

  echo "CADASTRANDO DUAS COMPANHIAS ÁEREAS: LATAM E AZUL" . "\n";
  $companhiaLatam= new CompanhiaAerea("Latam", "001", "Latam Airlines do Brasil S.A.","81435185000169", "LA", 20.00);
  $companhiaAzul= new CompanhiaAerea("Azul", "002", "Azul Linhas Aéreas Brasileiras S.A.","23654444325698", "AD", 25.00);
  echo "Companhias cadastradas com sucesso!" . "\n";
  echo "\n";
  //cadastra duas companhias áreas

  echo "CADASTRANDO DUAS AERONAVES DA EMBRAER PERTENCENTES À LATAM E AZUL" . "\n";
  $newEmbraer1 = new Aeronave("Embraer", "175", $companhiaLatam, 180, 600.00, 750);
  $newEmbraer2 = new Aeronave("Embraer", "175", $companhiaAzul, 180, 600.00, 750);
  echo "Aeronaves cadastradas com sucesso!" . "\n";
  echo "\n";
  //cadastra duas aeronaves da Embraer

  echo "TENTATIVA 1: CADASTRANDO REGISTRO DA PRIMEIRA AERONAVE:";
  echo "\n";
  $siglaEmbraer = "PX";
  $newEmbraer1->SetRegAeronave($siglaEmbraer, "RUZ");
  //Insere PX como sigla para a primeira aeronave
  echo "\n";

  echo "TENTATIVA 2: CADASTRANDO REGISTRO DA PRIMEIRA AERONAVE:";
  echo "\n";
  $siglaEmbraer = "PP";
  $newEmbraer1->SetRegAeronave($siglaEmbraer, "RUZ");
  //Insere PP como sigla para a primeira aeronave
  echo "\n";

  echo "TENTATIVA 1: CADASTRANDO REGISTRO DA SEGUNDA AERONAVE:";
  echo "\n";
  $siglaEmbraer = "PT";
  $newEmbraer1->SetRegAeronave($siglaEmbraer, "AGR");
  //Insere PT como sigla para a segunda aeronave
  echo "\n";

  echo "REALIZANDO CADASTRO DE AEROPORTOS:";
  echo "\n";
  echo "Cadastrando aeroporto de Confins: ";
  $confins = new Aeroporto("CNF","Confins","Minas Gerais");
  echo "Cadastrando aeroporto de Guarulhos: ";
  $guarulhos = new Aeroporto("GUA","Guarulhos","São Paulo");
  echo "Cadastrando aeroporto de Congonhas: ";
  $congonhas = new Aeroporto("CGH","São Paulo","São Paulo");
  echo "Cadastrando aeroporto de Galeão: ";
  $galeao = new Aeroporto("GIG","Rio de Janeiro","Rio de Janeiro");
  echo "Cadastrando aeroporto de Afonso Pena: ";
  $afonsopena = new Aeroporto("CWB","São José dos Pinhais","Paraná");
  echo "\n";
  // cadastra 5 aeroportos distintos

  echo "REALIZANDO CADASTRO DO VOO AC1329 ENTRE CONFINS E GUARULHOS (MANHÃ):";
  echo "\n";
  $horarioPartida = new DateTime();
  $horarioPartida->setTime(8, 0, 0);    //seta o horário de partida às 8:00
  $newVoo = new Voo($companhiaAzul, $confins, $guarulhos, $horarioPartida, 71);
  $newVoo->setCodigoVoo("AC1329");
  echo "\n";
  echo "\n";
  //cria um Voo de código AD-1329 da companhia Azul às 8:00 entre Confins e Guarulhos com 71 minutos de duração

  echo "REALIZANDO CADASTRO DE VOO AD-1330 ENTRE CONFINS E GUARULHOS (TARDE) :";
  echo "\n";
  $horarioPartida = new DateTime();
  $horarioPartida->setTime(16, 0, 0);    //seta o horário de partida às 16:00
  $newVoo2 = new Voo($companhiaAzul, $confins, $guarulhos, $horarioPartida, 75);
  $newVoo2->setCodigoVoo ("AD1330");
  echo "\n";
  echo "\n";
  //cria um Voo de código AD-1330 da companhia Azul às 16:00 entre Confins e Guarulhos com 75 minutos de duração

  echo "REALIZANDO CADASTRO DE VOO LA-0001 ENTRE CONFINS E CONGONHAS (MANHÃ) :";
  echo "\n";
  $horarioPartida = new DateTime();
  $horarioPartida->setTime(9, 0, 0);    //seta o horário de partida às 9:00
  $newVoo3 = new Voo($companhiaLatam, $confins, $congonhas, $horarioPartida, 96);
  $newVoo3->setCodigoVoo("LA0001");
  echo "\n";
  echo "\n";
  //cria um Voo de código LA-0001 da companhia Latam às 9:00 entre Confins e Congonhas com 96 minutos de duração

  echo "REALIZANDO CADASTRO DE VOO LA-0002 ENTRE CONFINS E CONGONHAS (TARDE) :";
  echo "\n";
  $horarioPartida = new DateTime();
  $horarioPartida->setTime(15, 0, 0);    //seta o horário de partida às 15:00
  $newVoo4 = new Voo($companhiaLatam, $confins, $congonhas, $horarioPartida, 100);
  $newVoo4->setCodigoVoo("LA0002");
  echo "\n";
  echo "\n";
  //cria um Voo de código LA-0002 da companhia Latam às 15:00 entre Confins e Congonhas com 100 minutos de duração

  echo "REALIZANDO CADASTRO DE VOO LA-1412 ENTRE GUARULHOS E GALEÃO (MANHÃ) :";
  echo "\n";
  $horarioPartida = new DateTime();
  $horarioPartida->setTime(6, 0, 0);    //seta o horário de partida às 6:00
  $newVoo5 = new Voo($companhiaLatam, $guarulhos, $galeao, $horarioPartida, 60);
  $newVoo5->setCodigoVoo("LA-1412");
  echo "\n";
  echo "\n";
  //cria um Voo de código LA-1412 da companhia Latam às 6:00 entre Guarulhos e Galeão com 60 minutos de duração

  echo "REALIZANDO CADASTRO DE VOO LA-1413 ENTRE GUARULHOS E GALEÃO (TARDE) :";
  echo "\n";
  $horarioPartida = new DateTime();
  $horarioPartida->setTime(14, 0, 0);    //seta o horário de partida às 14:00
  $newVoo6 = new Voo($companhiaLatam, $guarulhos, $galeao, $horarioPartida, 60);
  $newVoo6->setCodigoVoo("LA-1413");
  echo "\n";
  echo "\n";
  //cria um Voo de código LA-1413 da companhia Latam às 14:00 entre Guarulhos e Galeão com 60 minutos de duração

  echo "REALIZANDO CADASTRO DE VOO AD-2765 ENTRE CONGONHAS E AFONSO PENA (MANHÃ) :";
  echo "\n";
  $horarioPartida = new DateTime();
  $horarioPartida->setTime(8, 0, 0);    //seta o horário de partida às 8:00
  $newVoo7 = new Voo($companhiaAzul, $congonhas, $afonsopena, $horarioPartida, 63);
  $newVoo7->setCodigoVoo("ad-2765");
  echo "\n";
  echo "\n";
  //cria um Voo de código AD-2765 da companhia Azul às 8:00 entre Congonhas e Afonso Pena com 63 minutos de duração

  echo "REALIZANDO CADASTRO DE VOO AD-2765 ENTRE CONGONHAS E AFONSO PENA (TARDE) :";
  echo "\n";
  $horarioPartida = new DateTime();
  $horarioPartida->setTime(17, 0, 0);    //seta o horário de partida às 17:00
  $newVoo8 = new Voo($companhiaAzul, $congonhas, $afonsopena, $horarioPartida, 65);
  $newVoo8->setCodigoVoo("AD-2766");
  echo "\n";
  echo "\n";
  //cria um Voo de código AD-2766 da companhia Azul às 17:00 entre Congonhas e Afonso Pena com 65 minutos de duração
?>