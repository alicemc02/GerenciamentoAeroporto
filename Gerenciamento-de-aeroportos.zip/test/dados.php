<?php

  include_once("../global.php");

  Usuario::fazLoginAdmin ("admin", "admin");
{
  $companhiaLatam= new CompanhiaAerea("Latam", "001", "Latam Airlines do Brasil S.A.","81435185000169", "LA", 20.00);
  $companhiaAzul= new CompanhiaAerea("Azul", "002", "Azul Linhas Aéreas Brasileiras S.A.","23654444325698", "AD", 25.00);
	$companhiaAzul->set("precoBagagem", 300);
	$companhiaLatam->save(); 
$companhiaAzul->save();

  $newEmbraer1 = new Aeronave("Embraer", "175", $companhiaLatam, 180, 600.00, 750);
  $newEmbraer2 = new Aeronave("Embraer", "175", $companhiaAzul, 180, 600.00, 750);

  $newEmbraer1->SetRegAeronave("PP", "RUZ");
  $newEmbraer1->SetRegAeronave("PT", "AGR");
$newEmbraer1->save();
$newEmbraer2->save();

		$newVeiculo1 = new Veiculo(7, 856589, 20);
	$newVeiculo1->save();

	$newPrograma1 = new ProgramaMilhagem("TudoAzul", 123456, $companhiaAzul);
$newPrograma1->save();

$newPrograma2 = new ProgramaMilhagem("Latido", 789000, $companhiaLatam);
$newPrograma2->save();

  $coorConfins = new Coordenadas(-19.6238, -43.9713);
  $confins = new Aeroporto("CNF","Confins","Minas Gerais", $coorConfins);
$confins->save();
	
  $coorGuarulhos = new Coordenadas(-23.4322, -46.4692);
  $guarulhos = new Aeroporto("GUA","Guarulhos","São Paulo", $coorGuarulhos);
$guarulhos->save();
	
  $coorCongonhas = new Coordenadas(-23.6261, -46.6563);
  $congonhas = new Aeroporto("CGH","São Paulo","São Paulo", $coorCongonhas);
$congonhas->save();
	
  $coorGaleao = new Coordenadas(-22.8089, -43.2436);
  $galeao = new Aeroporto("GIG","Rio de Janeiro","Rio de Janeiro", $coorGaleao);
$galeao->save();

  $coorAfonso = new Coordenadas(-23.5316, -49.1761);
  $afonsopena = new Aeroporto("CWB","São José dos Pinhais","Paraná", $coorAfonso);
$afonsopena->save();

  $horarioPartida = new DateTime();
  $horarioPartida->setTime(8, 0, 0);    //seta o horário de partida às 8:00
  $newVoo1 = new Voo($companhiaAzul, $confins, $guarulhos, $horarioPartida, 71);
  $newVoo1->setCodigoVoo("AC1329");
$newVoo1->set("tarifa", 1300);
  //cria um Voo de código AD-1329 da companhia Azul às 8:00 entre Confins e Guarulhos com 71 minutos de duração
$newVoo1->save();

  $horarioPartida = new DateTime();
  $horarioPartida->setTime(16, 0, 0);    //seta o horário de partida às 16:00
  $newVoo2 = new Voo($companhiaAzul, $confins, $guarulhos, $horarioPartida, 75);
  $newVoo2->setCodigoVoo ("AD1330");
  //cria um Voo de código AD-1330 da companhia Azul às 16:00 entre Confins e Guarulhos com 75 minutos de duração
$newVoo2->save();

  $horarioPartida = new DateTime();
  $horarioPartida->setTime(9, 0, 0);    //seta o horário de partida às 9:00
  $newVoo3 = new Voo($companhiaLatam, $confins, $congonhas, $horarioPartida, 96);
  $newVoo3->setCodigoVoo("LA0001");
  //cria um Voo de código LA-0001 da companhia Latam às 9:00 entre Confins e Congonhas com 96 minutos de duração
$newVoo3->save();

  $horarioPartida = new DateTime();
  $horarioPartida->setTime(15, 0, 0);    //seta o horário de partida às 15:00
  $newVoo4 = new Voo($companhiaLatam, $confins, $congonhas, $horarioPartida, 100);
  $newVoo4->setCodigoVoo("LA0002");
  //cria um Voo de código LA-0002 da companhia Latam às 15:00 entre Confins e Congonhas com 100 minutos de duração
$newVoo4->save();

  $horarioPartida = new DateTime();
  $horarioPartida->setTime(6, 0, 0);    //seta o horário de partida às 6:00
  $newVoo5 = new Voo($companhiaLatam, $guarulhos, $galeao, $horarioPartida, 60);
  $newVoo5->setCodigoVoo("LA-1412");
  //cria um Voo de código LA-1412 da companhia Latam às 6:00 entre Guarulhos e Galeão com 60 minutos de duração
$newVoo5->save();

  $horarioPartida = new DateTime();
  $horarioPartida->setTime(14, 0, 0);    //seta o horário de partida às 14:00
  $newVoo6 = new Voo($companhiaLatam, $guarulhos, $galeao, $horarioPartida, 60);
  $newVoo6->setCodigoVoo("LA-1413");
  //cria um Voo de código LA-1413 da companhia Latam às 14:00 entre Guarulhos e Galeão com 60 minutos de duração
$newVoo6->save();

  $horarioPartida = new DateTime();
  $horarioPartida->setTime(8, 0, 0);    //seta o horário de partida às 8:00
  $newVoo7 = new Voo($companhiaAzul, $congonhas, $afonsopena, $horarioPartida, 63);
  $newVoo7->setCodigoVoo("ad-2765");
  //cria um Voo de código AD-2765 da companhia Azul às 8:00 entre Congonhas e Afonso Pena com 63 minutos de duração
$newVoo7->save();

  $horarioPartida = new DateTime();
  $horarioPartida->setTime(17, 0, 0);    //seta o horário de partida às 17:00
  $newVoo8 = new Voo($companhiaAzul, $congonhas, $afonsopena, $horarioPartida, 65);
  $newVoo8->setCodigoVoo("AD-2766");
  //cria um Voo de código AD-2766 da companhia Azul às 17:00 entre Congonhas e Afonso Pena com 65 minutos de duração
$newVoo8->save();

echo("\n========================================\n");

	$horaPartida = new DateTime();
  	$horaPartida->setTime(17, 0, 0);
	$horaChegada = new DateTime();
  	$horaChegada->setTime(20, 0, 0);
	$data = new DateTime('2023/06/09');
	$newViagem1 = new Viagem($data, $horaPartida, $horaChegada, $newEmbraer1, $newVoo1);
	$newViagem1->set("multa", 650);
	$newViagem1->save();

	$horaPartida = new DateTime();
  	$horaPartida->setTime(23, 0, 0);
	$horaChegada = new DateTime();
  	$horaChegada->setTime(05, 0, 0);
	$data = new DateTime('2023/06/07');
	$newViagem2 = new Viagem($data, $horaPartida, $horaChegada, $newEmbraer2, $newVoo2);
$newViagem2->save();

	$horaPartida = new DateTime();
  	$horaPartida->setTime(21, 0, 0);
	$horaChegada = new DateTime();
  	$horaChegada->setTime(12, 0, 0);
	$data = new DateTime();
	$newViagem3 = new Viagem($data, $horaPartida, $horaChegada, $newEmbraer1, $newVoo3);
$newViagem3->save();

	$horaPartida = new DateTime();
  	$horaPartida->setTime(10, 0, 0);
	$horaChegada = new DateTime();
  	$horaChegada->setTime(15, 0, 0);
	$data = new DateTime();
	$newViagem4 = new Viagem($data, $horaPartida, $horaChegada, $newEmbraer2, $newVoo4);
$newViagem4->save();

	$horaPartida = new DateTime();
  	$horaPartida->setTime(03, 0, 0);
	$horaChegada = new DateTime();
  	$horaChegada->setTime(05, 0, 0);
	$data = new DateTime('2023/06/09');
	$newViagem5 = new Viagem($data, $horaPartida, $horaChegada, $newEmbraer1, $newVoo5);
$newViagem5->save();

	$horaPartida = new DateTime();
  	$horaPartida->setTime(12, 0, 0);
	$horaChegada = new DateTime();
  	$horaChegada->setTime(13, 0, 0);
	$data = new DateTime();
	$newViagem6 = new Viagem($data, $horaPartida, $horaChegada, $newEmbraer2, $newVoo6);
$newViagem6->save();

	$horaPartida = new DateTime();
  	$horaPartida->setTime(03, 0, 0);
	$horaChegada = new DateTime();
  	$horaChegada->setTime(23, 0, 0);
	$data = new DateTime();
	$newViagem7 = new Viagem($data, $horaPartida, $horaChegada, $newEmbraer1, $newVoo7);
$newViagem7->save();

	$horaPartida = new DateTime();
  	$horaPartida->setTime(22, 0, 0);
	$horaChegada = new DateTime();
  	$horaChegada->setTime(04, 0, 0);
	$data = new DateTime();
	$newViagem8 = new Viagem($data, $horaPartida, $horaChegada, $newEmbraer2, $newVoo8);
$newViagem8->save();

	$horaPartida = new DateTime();
  	$horaPartida->setTime(20, 0, 0);
	$horaChegada = new DateTime();
  	$horaChegada->setTime(14, 0, 0);
	$data = new DateTime();
	$newViagem9 = new Viagem($data, $horaPartida, $horaChegada, $newEmbraer1, $newVoo1);
$newViagem9->save();

$date = new DateTime('1971/01/01');
	$newPassageiro1 = new Passageiro("Marcela Melissa", "Tânia Fernandes", "44.706.702-3", 92350800458, "BRASILEIRO", $data, "marcela-fernandes74@geopx.com.br");
$newPassageiro1->save();

$data = new DateTime('1972/01/20');
	$newPassageiro2 = new Passageiro("Kaique Bruno", "Alves", "50.188.664-3", 20835106586, "BRASILEIRO", $data, "kaique_alves@googlemail.com");
$newPassageiro2->save();

$data = new DateTime('2001/06/03');
	$newPassageiro3 = new Passageiro("Emanuelly Maria", "Valentina da Conceição", "34.339.136-3", 79039117675, "BRASILEIRO", $data, "emanuellymariadaconceicao@allianceconsultoria.com.br");
$newPassageiro3->save();

$data = new DateTime('1969/02/26');
	$newPassageiro4 = new Passageiro("Victor Lorenzo", "Rodrigo Martins", "46.851.310-3", 32611512345, "BRASILEIRO", $data, "victor_martins@belbrindes.com");
$newPassageiro4->save();

$data = new DateTime('1968/03/16');
	$newPassageiro5 = new Passageiro("Lúcia Nicole", "Barbosa", "34.595.272-8", 72897935952, "BRASILEIRO", $data, "lucia-barbosa95@marcofaria.com");
$newPassageiro5->save();

$data = new DateTime('1964/05/14');
	$newPassageiroVip1 = new PassageiroVip("Ruan", "Yago da Cunha", "34.817.341-6", 78918194838, "BRASILEIRO", $data, "ruan_dacunha@raya3.com.br");
	$newPassageiroVip1->set("programaFavorito", $newPrograma1);
$newPassageiroVip1->save();

$data = new DateTime('1967/03/07');
	$newPassageiroVip2 = new PassageiroVip("Julio Alexandre", "Pedro Henrique Pereira", "45.234.520-0", 21971934062, "BRASILEIRO", $data, "julio_pereira@piscinasegura.com.br");
$newPassageiroVip2->save();

$data = new DateTime('1979/04/13');
	$newPassageiroVip3 = new PassageiroVip("Beatriz Giovanna", "Alana Ribeiro", "41.959.191-6", 25009542005, "BRASILEIRO", $data, "beatriz-ribeiro83@lonax.net");
$newPassageiroVip3->save();

$data = new DateTime('1970/04/26');
	$newPassageiroVip4 = new PassageiroVip("Mariana Letícia", "Almada", "43.303.844-5", 31420004450, "BRASILEIRO", $data, "mariana_almada@athos.srv.br");
$newPassageiroVip4->save();

$data = new DateTime('1954/04/11');
	$newPassageiroVip5 = new PassageiroVip("Diego Vitor", "Joaquim da Rosa", "49.196.372-5", 97361039600, "BRASILEIRO", $data, "diegovitordarosa@innovatis.com.br");
$newPassageiroVip5->save();

$data = new DateTime('1996/04/19');
	$newTripulante1 = new Tripulante("Jéssica Marli", "Juliana Baptista", "13.978.239-4", 29667160025, "BRASILEIRO", $data, "jessica_marli_baptista@msds.com.br", 644932, 321, 07161220, "Rua Dianópolis", "Cidade Soberana", "Guarulhos", "SP", "Brasil", TipoTripulante::COMISSARIO, $companhiaLatam, $guarulhos);
$newTripulante1->save();

$data = new DateTime('1961/03/01');
	$newTripulante2 = new Tripulante("Jennifer", "Olivia Assis", "27.157.685-6", 82078185140, "BRASILEIRO", $data, "jennifer-assis74@asconinternet.com.br", 893728, 526, 71536366, "Trecho Trecho 06 Chácara 217", "Setor de Habitações Individuais Norte", "Brasília", "DF", "Brasil", TipoTripulante::COMISSARIO, $companhiaLatam, $guarulhos);
$newTripulante2->save();

$data = new DateTime('1972/01/14');
	$newTripulante3 = new Tripulante("Carlos Eduardo", "Yuri da Luz", "46.005.688-8", 58388946013, "BRASILEIRO", $data, "carlos.eduardo.daluz@sistectecnologia.com.br", 308870, 893, 58706160, "Rua Manoel Gonçalves", "São Sebastião", "Patos", "PB", "Brasil", TipoTripulante::PILOTO, $companhiaLatam, $guarulhos);
$newTripulante3->save();

$data = new DateTime('1999/04/15');
	$newTripulante4 = new Tripulante("Benício Luan", "Campos", "22.192.466-8", 35645440463, "BRASILEIRO", $data, "benicio_luan_campos@eanac.com.br", 261979, 953, 69316076, "Rua Estrela Celeste", "Raiar do Sol", "Boa Vista", "RR", "Brasil", TipoTripulante::PILOTO, $companhiaLatam, $guarulhos);
$newTripulante4->save();

$data = new DateTime('1985/02/10');
	$newTripulante5 = new Tripulante("Beatriz", "Andreia Moreira", "48.659.756-8", 59426362142, "BRASILEIRO", $data, "beatriz_andreia_moreira@hellokitty.com", 128488, 655, 57044042, "Rua Doutor José Verres Domingues", "São Jorge", "Maceió", "AL", "Brasil", TipoTripulante::COMISSARIO, $companhiaLatam, $guarulhos);
$newTripulante5->save();

}//preenchendo o banco de dados
?>