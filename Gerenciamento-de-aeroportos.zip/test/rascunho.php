<?php

  include_once("../global.php");

  Usuario::fazLoginAdmin ("admin", "admin");
$viajVip = PassageiroVip::pesquisarPassageiro("Ruan", "Yago da Cunha");
//$viajVip->setPontuacaoVigente(8000);
//var_dump($viajVip);
$viajVip->set("pontuacaoVigente",8000);
$data10 = new DateTime('2023/06/13');
$data20 = new DateTime('2022/06/12');
$data30 = new DateTime('2022/01/04');
$data1 = $data10->format('d-m-y h:i:s');
$data2 = $data20->format('d-m-y h:i:s');
$data3 = $data30->format('d-m-y h:i:s');
$array = array(
	$data1 => 4000,
	$data2 => 1000,
	$data3 =>3000);
$viajVip->set("regPontuacao", $array);
$viajVip->vencerPontuacaoVigente();
var_dump($viajVip);
/*
$companhiaLatam= new CompanhiaAerea("Latam", "001", "Latam Airlines do Brasil S.A.","81435185000169", "LA", 20.00);
$newEmbraer1 = new Aeronave("Embraer", "175", $companhiaLatam, 180, 600.00, 750);
$coorConfins = new Coordenadas(-19.6238, -43.9713);
$confins = new Aeroporto("CNF","Confins","Minas Gerais", $coorConfins);
$coorGuarulhos = new Coordenadas(-23.4322, -46.4692);
$guarulhos = new Aeroporto("GUA","Guarulhos","São Paulo", $coorGuarulhos);

$horarioPartida = new DateTime();
$horarioPartida->setTime(9, 0, 0);    //seta o horário de partida às 9:00
$newVoo3 = new Voo($companhiaLatam, $confins, $guarulhos, $horarioPartida, 90);
$newVoo3->setCodigoVoo("LA0001");

$data = new DateTime('2023/06/13');
$viagem = new Viagem($data, $newEmbraer1, $newVoo3);
$data->setTime(9, 30, 0);
$viagem->setHoraPartida($data);
//var_dump($viagem);
$newVoo3->setFrequenciaSemanal("Domingo", true);
$newVoo3->setFrequenciaSemanal("Segunda", false);
$newVoo3->setFrequenciaSemanal("Terça", true);
$newVoo3->setFrequenciaSemanal("Quarta", false);
$newVoo3->setFrequenciaSemanal("Quinta", true);
$newVoo3->setFrequenciaSemanal("Sexta", false);
$newVoo3->setFrequenciaSemanal("Sábado", true);
//$newVoo3->salvarDatasFuturas();
$newVoo3->set("aeronave", $newEmbraer1);
//$newVoo3->criarViagensFuturas();
$dataP = new DateTime('2023/06/13');
$dataP->setTime(11, 30, 0);
$viagem->executarViagem($dataP);
var_dump($newVoo3);


/*

$viajVip->set("pontuacaoVigente",3000);
//$viajVip->save();
//var_dump($viajVip);
//ProgramaMilhagem::fazerUpgrade($viajVip);
//var_dump($viajVip);
//$viajVip->set("pontuacaoVigente",3000);
//ProgramaMilhagem::fazerDowngrade($viajVip);
//var_dump($viajVip);

$cliente = new Cliente("Joao", "da Silva", "123456");
$data = new DateTime('2023/06/09');
$viagem = Viagem::pesquisarViagem("CNF", "GUA", $data,1);
$pass = Passagem::comprarPassagem($cliente, "Ruan", "Yago da Cunha", "CNF", "GUA", $data);
$pass->set("assentoReservado", "55A");
$pass->setBagagem(12, 20, 16);
$array = array($pass);
//$pass->set("statusPassageiro", StatusPassageiro::EMBREALIZADO);
$viagem[0]->set("viajantes", $array);
$viagem[0]->set("pontuacaoConcedida",1000);

//$viagem[0]->pontuarPassageiro();
//var_dump($viagem[0]->get("viajantes"));



$pass->fazerCheckin($pass->get("viagem")->get("dataViagem"));
var_dump($pass->get("cartaoEmbarque"));
//var_dump($viajVip);
/*
$array = array(
	"55A" => true,
	"55B" =>false,
	"55C" => false,
	"55D" => true
);	
		
var_dump($disponiveis);


//var_dump($pass);
//var_dump($pass->calcularTotal());
//var_dump($conexao);
/*
$viaj = Passageiro::pesquisarPassageiro("Marcela Melissa", "Tânia Fernandes");


$voo = Viagem::pesquisarViagem("CNF", "GUA", $data, 1);
//var_dump($voo);


//$mul = $voo[0]->calcularRessarcimento($viajVip,false);
$tot = $pass->calcularTotal();
//var_dump($tot);

//$voo[0]->set("dataViagem", new DateTime('2023/06/09'));

//var_dump($voo[0]);


$pass->alterarPassagem("precoPassagem",500);

//$pass->cancelarPassagem();
//var_dump($pass);
//var_dump($mul);
//print(sizeof($voo));
//var_dump($voo)
//
/*
$viagens = Viagem::getRecords();
$viagem=$viagens[0];
$veiculo = Veiculo::getRecords();
$trip = Tripulante::getRecords();
$tripulacao = array();
for($i = 0; $i<5; $i++){
	$tripulacao[$i] = $trip[$i];
}
//var_dump($tripulacao);
$viagens[0]->set("tripulacao", $tripulacao);
//var_dump($viagens[0]);
$veiculo[0]->set("viagemAtendida",$viagens[0]);
//var_dump($veiculo);
$cood = array();
for($i = 0; $i< 5; $i++){
	$trip = $veiculo[0]->get("viagemAtendida")->get("tripulacao");
	$cood[$i] = Coordenadas::converterEndereco($trip[$i]->get("cep"));
}
$veiculo[0]->construirRota();
$veiculo[0]->get("rotaAtendida")->calcularHorarioEmbarque($viagem->get("horaPartida"), $viagem->get("voo")->get("aeroportoPartida"), $veiculo[0]->get("velocidadeMedia"));
var_dump($veiculo[0]->get("rotaAtendida")->get("horarioEmbarque"));
//$pass = Passageiro::pesquisarPassageiro("Marcela Melissa", "Tânia Fernandes");
//var_dump($pass);
//var_dump($cood);
/*
$viagem = $veiculo[0]->get("viagemAtendida");

*/
//var_dump($veiculo[0]->get("rotaAtendida")->get("horarioEmbarque"));
//var_dump($veiculo[0]);
//$cod = $veiculo[0]->get("rotaAtendida")->get("enderecosVisitados");
//$dist = Coordenadas::calcularDistancia($cod[0], $cod[1]);
//print($dist);
//$t = $veiculo[0]->calcularTempo(145);
//print($t);
//$horaFinal = new DateTime();
//$horaFinal->sub(new DateInterval('PT90M'));
//var_dump($horaFinal);

?>