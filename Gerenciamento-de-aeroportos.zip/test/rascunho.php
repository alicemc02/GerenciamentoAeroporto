<?php

  include_once("../global.php");

  Usuario::fazLoginAdmin ("admin", "admin");

$data = new DateTime('2023/06/07');
Passagem::comprarPassagem("Marcela Melissa", "Tânia Fernandes", "CNF", "GUA", $data)
/*$voo = Viagem::pesquisarViagem("CNF", "GUA", $data, 1);
print(sizeof($voo));
//var_dump($voo)
//
$pass = Passageiro::pesquisarPassageiro("Marcela Melissa", "Tânia Fernandes");
var_dump($pass);*/
?>