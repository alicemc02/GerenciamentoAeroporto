<?php 

// =====================================================
//Inclusão das classes necessárias para testar a classe aeroporto.
  include_once("../global.php");

// =====================================================
//TESTA O CONSTRUTOR DE UM AEROPORTO:
  //SIGLA: CNF
  //CIDADE: Confins
  //ESTADO: Minas Gerais
  $newAeroporto = new Aeroporto("CNF","Confins","Minas Gerais");
  echo "Testando o construtor de Aeronave" . "\n";
  print_r($newAeroporto);
  echo "\n";
  echo "Teste concluído!". "\n";
  echo "\n";
  echo "\n";
// =============================================================

// TESTA O MÉTODO "getSigla()" QUE RETORNA A SIGLA ATUAL
echo "-> Testando o método getSigla(). A sigla atual é:" . "\n";
$siglaAeroporto = $newAeroporto->getSigla();
print_r($siglaAeroporto);
echo "\n";
echo "Teste concluído!". "\n";
echo "\n";
echo "\n";

// =============================================================


// TESTA O MÉTODO "setSigla()" QUE SETA UMA OUTRA SIGLA
$newAeroporto->setSigla("UBE");
$novaSiglaAeroporto = $newAeroporto->getSigla();
echo "-> Testando o setSigla(). A nova sigla é:" . "\n";
print_r($novaSiglaAeroporto);
echo "\n";
echo "Teste concluído!". "\n";
echo "\n";
echo "\n";
// =============================================================


// TESTA O MÉTODO "setSigla() e o método verificarSigla()" QUE VERIFICA SE A SIGLA POSSUI TRÊS LETRAS
$newAeroporto->setSigla("RJA");
$novaSiglaAeroporto = $newAeroporto->getSigla();
echo "-> Testando o setSigla() e verificaSigla(). A nova sigla é:" . "\n";
print_r($novaSiglaAeroporto);
echo "\n";
echo "Teste concluído!". "\n";
echo "\n";
echo "\n";
// =============================================================


// TESTA O MÉTODO "getCidade()" QUE RETORNA A CIDADE ATUAL
echo "-> Testando o método getCidade(). A cidade atual é:" . "\n";
$cidadeAeroporto = $newAeroporto->getCidade();
print_r($cidadeAeroporto);
echo "\n";
echo "Teste concluído!". "\n";
echo "\n";
echo "\n";

// =============================================================


// TESTA O MÉTODO "setCidade()" QUE SETA UMA OUTRA CIDADE
$newAeroporto->setCidade("Búzios");
$novaCidadeAeroporto = $newAeroporto->getCidade();
echo "-> Testando o setCidade(). A nova cidade deste aeroporto é:" . "\n";
print_r($novaCidadeAeroporto);
echo "\n";
echo "Teste concluído!". "\n";
echo "\n";
echo "\n";
// =============================================================

// TESTA O MÉTODO "getEstado()" QUE RETORNA O ESTADO ATUAL
echo "-> Testando o método getEstado(). O estado atual é:" . "\n";
$estadoAeroporto = $newAeroporto->getEstado();
print_r($estadoAeroporto);
echo "\n";
echo "Teste concluído!". "\n";
echo "\n";
echo "\n";

// =============================================================


// TESTA O MÉTODO "setEstado()" QUE SETA UM OUTRO ESTADO
$newAeroporto->setEstado("Rio de Janeiro");
$novoEstadoAeroporto = $newAeroporto->getEstado();
echo "-> Testando o setEstado(). O novo estado deste aeroporto é:" . "\n";
print_r($novoEstadoAeroporto);
echo "\n";
echo "Teste concluído!". "\n";
echo "\n";
echo "\n";
// =============================================================

?>