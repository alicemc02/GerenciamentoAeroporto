<?php
include_once("../global.php");

  $data = new DateTime('1999-05-11');
  $pessoaWashington = new Pessoa("Washington", "Gomes", "MG456890123", 14642325638, "Brasileiro",$data, "washingtondopneu@yahoo.com.br");

  $pessoaWashington->validarEmail($pessoaWashington->getEmail());







?>