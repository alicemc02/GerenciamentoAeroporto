<?
  include_once("../global.php");
  include_once("../classes/class.Passagem.php");

  $new_cliente = new Cliente("Nelson","Rodrigues da Costa", "033.655.240-88");

  print_r($new_cliente);

  print_r($new_cliente->GetNome());
  print_r($new_cliente->GetSobrenome());
  print_r($new_cliente->GetDocumento());

?>