<?php

// =============================================================
//Inclusão das classes necessárias para testar a classe aeronave.
  include_once("../global.php");

// =============================================================
// TESTA O CONSTRUTOR DE UMA AERONAVE: ÚLTIMA ATUALIZAÇÃO - 18/05/2023: 19:32 - VALIDADO!

  //CRIA COMPANHIA - cria uma nova companhia para ser usada na passagem de parâmetro do construtor da aeronave:
  //NOME: TAM
  //CÓDIGO COMPANHIA: G U O
  //RAZÃO SOCIAL: TAM DISTRB. LTDA
  //CNJP: 81435185000169
  //SIGLA COMPANHIA: TM
  //PREÇO DA BAGAGEM: R$20,00
  $companhiaTAM = new CompanhiaAerea("TAM", "GUO", "TAM DISTRB. LTDA","81435185000169", "TM", 20.00);

//--------------------------------------------------------------------
  //CRIA AERONAVE - cria uma nova aeronave com:
  //FABRICANTE: Boeing
  //MODELO: A-747
  //COMPANHIA: Companhia fictícia da TAM
  //CAPACIDADE PASSAGEIROS: 50
  //CAPACIDADE DE CARGA: 2000KG
  $newAeronave = new Aeronave("Boeing", "A-747", $companhiaTAM, 50, 2000.89);
  echo "Testando o construtor de Aeronave" . "\n";
  print_r($newAeronave);
  echo "\n";
  echo "Teste concluído!". "\n";
  echo "\n";
  echo "\n";

// =============================================================


// TESTA O MÉTODO "getFileName()" QUE RETORNA aeronave.txt - 18/05/2023: 20:23 - VALIDADO!
echo "Testando o getFileName(). O arquivo retornado é:" . "\n";
$arquivotxt = $newAeronave->getFilename();
print_r($arquivotxt);
echo "\n";
echo "Teste concluído!". "\n";
echo "\n";
echo "\n";
// =============================================================


// TESTA O MÉTODO "getFabricante()" QUE RETORNA O FABRICANTE - 18/05/2023: 
echo "Testando o getFabricante(). O fabricante atual é:" . "\n";
$fabricante = $newAeronave->getFabricante();
print_r($fabricante);
echo "\n";
echo "Teste concluído!". "\n";
echo "\n";
echo "\n";
// =============================================================


// TESTA O MÉTODO "setFabricante()" QUE SETA UM OUTRO FABRICANTE - 18/05/2023:
$newAeronave->setFabricante("Airbus");
$novoFabricante = $newAeronave->getFabricante();
echo "Testando o setFabricante(). O novo fabricante é:" . "\n";
print_r($novoFabricante);
echo "\n";
echo "Teste concluído!". "\n";
echo "\n";
echo "\n";
// =============================================================


// TESTA O MÉTODO "getModelo()" QUE RETORNA O MODELO DE AERONAVE - 18/05/2023:
echo "Testando o getModelo(). O modelo atual é:" . "\n";
$modelo = $newAeronave->getModelo();
print_r($modelo);
echo "\n";
echo "Teste concluído!". "\n";
echo "\n";
echo "\n";
// =============================================================


// TESTA O MÉTODO "setModelo()" QUE SETA UM OUTRO MODELO - 18/05/2023:
echo "Testando o setModelo(). O novo modelo é:" . "\n";
$newAeronave->setModelo("R-456");
$novoModelo = $newAeronave->getModelo();
print_r($novoModelo);
echo "\n";
echo "Teste concluído!". "\n";
echo "\n";
echo "\n";
// =============================================================


// TESTA O MÉTODO "getRegAeronave()" QUE RETORNA O MODELO DE AERONAVE - 18/05/2023:
echo "Testando o getRegAeronave(). O registro de aeronave atual é:" . "\n";
$regAeronave = $newAeronave->getRegAeronave();
print_r($regAeronave);
echo "\n";
echo "Teste concluído!". "\n";
echo "\n";
echo "\n";
// =============================================================


// TESTA O MÉTODO "setRegAeronave()" QUE CONCATENA SIGLA HÍFEN E CÓDIGO ÚLTIMA ATUALIZAÇÃO - 20/04/2023: 20:27
  $sigla = TipoSigla::PR;
  $codigoTeste = "PHP";
  $codigoTeste2 = "QWER";
  $codigoTeste3 = "QQ";

  $newAeronave->SetRegAeronave($sigla, $codigoTeste);
  echo "Testando o setRegAeronave(). O novo registro de aeronave é:" . "\n";
  $novoRegAeronave = $newAeronave->getRegAeronave();
  print_r($novoRegAeronave);
  echo "\n";
  echo "Teste concluído!". "\n";
  echo "\n";
  echo "\n";

// =============================================================
// TESTA A FUNÇÃO "getCapPassageiros" QUE RETORNA A QUANTIDADE DE PASSAGEIROS DO AVIÃO - ÚLTIMA ATUALIZAÇÃO - 
  echo "Testando o getCapPassageiros(). A capacidade de passageiros atual é:" . "\n";
  $capacidadePassageiros = $newAeronave->getCapPassageiros();
  print_r($capacidadePassageiros);
  echo "\n";
  echo "Teste concluído!". "\n";
  echo "\n";
  echo "\n";
// =============================================================

// TESTA O MÉTODO "setCapPassageiros()" QUE SETA UMA NOVA CAPACIDADE DE PASSAGEIROS - 18/05/2023:
  echo "Testando o setCapPassageiros(). A nova capacidade de passageiros é:" . "\n";
  $newAeronave->setCapPassageiros(100);
  $novaCapacidadePassageiros = $newAeronave->getCapPassageiros();
  print_r($novaCapacidadePassageiros);
  echo "\n";
  echo "Teste concluído!". "\n";
  echo "\n";
  echo "\n";
// =============================================================


//TESTA A FUNÇÃO "getCapCarga() QUE RETORNA A CAPACIDADE DE CARGA DO AVIÃO"
  echo "Testando o getCapCarga(). A capacidade de carga atual é:" . "\n";
  $capacidadeCarga = $newAeronave->getCapCarga();
  print_r($capacidadeCarga);
  echo "\n";
  echo "Teste concluído!". "\n";
  echo "\n";
  echo "\n";
// =============================================================

// TESTA O MÉTODO "setCapCarga()" QUE SETA UMA NOVA CAPACIDADE DE CARGA - 18/05/2023:
  echo "Testando o setCapCarga(). A nova capacidade de carga é:" . "\n"; 
  $newAeronave->setCapCarga(3059.25);
  $novaCapacidadeCarga = $newAeronave->getCapCarga();
  print_r($novaCapacidadeCarga);
  echo "\n";
  echo "Teste concluído!". "\n";
  echo "\n";
  echo "\n";
// =============================================================


//TESTA A FUNÇÃO "getCompanhiaAerea() QUE RETORNA A COMPANHIA AÉREA DE UMA AERONAVE"
  echo "Testando o getCompanhiaAerea(). A companhia aérea atual é:" . "\n";
  $companhiaAerea = $newAeronave->getCompanhiaAerea();
  print_r($companhiaAerea);
  echo "\n";
  echo "Teste concluído!". "\n";
  echo "\n";
  echo "\n";
// =============================================================



// TESTA O MÉTODO "setCompanhiaAerea()" QUE SETA UMA NOVA COMPANHIA AÉREA - 18/05/2023:
  echo "Testando o setCompanhiaAerea(). A nova companhia aérea  é:" . "\n";
  $companhiaAzul = new CompanhiaAerea("Azul", "AZL", "AZUL DISTRB. LTD","31256196201121", "AZ", 15.00);
  $newAeronave-> setCompanhiaAerea($companhiaAzul);
  $novaCompanhiaAerea = $newAeronave->getCompanhiaAerea();
  print_r($novaCompanhiaAerea);
  echo "\n";
  echo "Teste concluído!". "\n";
  echo "\n";
  echo "\n";
// =============================================================
?>