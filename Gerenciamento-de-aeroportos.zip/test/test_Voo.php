<?php


// ===========================================

  include_once("../global.php");
  
// ===========================================

  $new_aeroporto_saida = new Aeroporto("CNF","Confins","Minas Gerais");

  $new_aerporto_chegada = new Aeroporto("CGH","Congonhas","São Paulo");

  $companhiaTAM = new CompanhiaAerea("TAM", "GUO", "TAM DISTRB. LTDA" ,"81435185000169", "TM", 23.00 );

  $hora = new DateTime();
  $hora->setTime(rand(0, 23), rand(0, 59), rand(0, 59));

  $new_voo = new Voo($companhiaTAM, $new_aeroporto_saida, $new_aerporto_chegada, $hora, 10 );

  //ainda pendente de teste
  $new_voo->SetCodigoVoo ("TM-1234");
  //print_r($companhiaTAM);
  print_r($new_voo);

?>