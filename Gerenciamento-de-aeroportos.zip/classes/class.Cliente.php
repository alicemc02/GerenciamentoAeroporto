<?php

  include_once("../global.php"); 

  class Cliente extends persist{
    private string $nome;
    private string $sobrenome;
    private string $documento;

    //**********###############**********
    //##########Class functions##########
    //**********###############**********
    
	static public function getFilename(){
    	return "Cliente.txt";
   	}//getFilename
     
	public function __construct(string $p_nome, string $p_sobrenome, string $p_documento){
      if (!(Login::checaLogin())) return;
       $this->nome = $p_nome;
       $this->sobrenome = $p_sobrenome;
       $this->documento = $p_documento;
  	}//construct

	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set
	  
}//class