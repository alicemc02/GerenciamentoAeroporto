<?php
include_once("../global.php");

class Veiculo extends persist {
  	private int $capVeiculo;
	private int $numeroVeiculo;
	private float $velocidadeMedia;//em Km/h
  	
	private Rota $rotaAtendida;
  	private Viagem $viagemAtendida;
  
  	private $horarioEmbarque; //<string, Datetime>
	//**********###############**********//
    //##########Class functions##########//
    //**********###############**********//
    
	static public function getFilename(){
    	return "Veiculo.txt";
   	}//getFilename
	
  	public function __construct(int $p_capVeiculo, int $p_numeroVeiculo, float $p_velMedia) {
    	if (!(Usuario::checaLogin())) return;
    	$this->capVeiculo = $p_capVeiculo;
    	$this->numeroVeiculo = $p_numeroVeiculo; 
		$this->velocidadeMedia = $p_velMedia;
  	}//construct
	
	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set

	public function construirRota(){
		$tripulacao = $this->get("viagemAtendida")->get("tripulacao");
		$coordenadas = array();
		for($i = 0; $i<sizeof($tripulacao); $i++){
			$coordenadas[$i] = Coordenadas::converterEndereco($tripulacao[$i]->get("cep"));
		}//for
		$this->rotaAtendida = new Rota($coordenadas);
	}//construirRota

	//calcula o tempo em min
	public function calcularTempo(float $distancia){
    	$i_tempo = $distancia/$this->velocidadeMedia;
		$tempo = $i_tempo * 60;
    	return $tempo;
  }//calcularTempo
	
  	public function adicionarHorarioEmbarque(Datetime $horarioPartida){
		$horaChegada = $horarioPartida;
		$horaChegada->sub(new DateInterval('PT90M'));//subtrai 90 minutos da hora da viagem, para saber o horario de chegada
    	
  	}//adicionarHorarioEmbarque
	
}//class