<?php
include_once("../global.php");  
define('INTERVALO_EMBARQUE', 40);//minutos 

class Viagem extends persist{
    private DateTime $dataViagem;
    private DateTime $horaPartida;
    private DateTime $horaChegada;
    
	private int $pontuacaoConcedida;
	 
	private Aeronave $aeronave;
	private Voo $voo;
	private $tripulacao;// array de tripulantes
	private $viajantes;//array de passagens
	
	private $assentos;//array de string e bool
	private float $multa;
	
	//**********###############**********
    //##########Class functions##########
    //**********###############**********
      
	static public function getFilename(){
      	return "Viagem.txt";
    }//getFilename
        
    public function __construct(DateTime $p_dataViagem, Aeronave $p_aeronave, Voo $p_voo){
        if (!(Usuario::checaLogin())) return;
		$this->tripulacao = array();
		$this->assentos = array();
		$this->viajantes = array();
		
        $this->dataViagem = $p_dataViagem;
        $this->aeronave = $p_aeronave;
		$this->voo = $p_voo;
    }//construct
	
	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set

	public function setHoraPartida(DateTime $horaPartida){
		$this->horaPartida = $horaPartida;
		$duracao = $this->voo->get("duracaoEstimada");
		$xerox = clone $horaPartida;
		$this->horaChegada = $xerox->add(new DateInterval('PT'.$duracao.'M'));
	}//setHorarioPartida
	
	public function setAssentos(string $novoAssento, bool $ocupado){
		$this->assentos[$novoAssento] = $ocupado;
	}//setAssentos
	  
	public function gerarAssentos(int $numAssentos){
		$nAssentos = numAssentos;
    	$posicaoBanco = 1;
    	$letra = 0;
    	$momento = 2;
        for($x=1;$x<=$nAssentos;$x+=1,$momento--,$posicaoBanco++){
          	$banco = chr($letra+65) . $posicaoBanco ;
          	array_push($assentos,$banco);
          	if($momento>0){}//if
          	else{
			  	$momento=3;$letra++;$posicaoBanco=0;
		  	}//else
		}//for	
	}//gerarAssentos
	  
    private function setAssentoFalse(string $p_assentoCancelado){ //método utilizado APENAS pela classe Passagem durante cancelamento
      $this->assentos[$p_assentoCancelado] = false;                                                         
	}//setAssentoFalse

    public function reservarAssento(string $lugar){
    	if($this->assentos[$lugar] == false){
      		$this->assentos[$lugar] = true;
		}//if
    	else{
    		throw(new Exception('O lugar já está reservado, escolha outro lugar.'));
		}//else
	}//reservarAssento

	public function mostrarAssentosDisponiveis(){
		$disponiveis = array_keys($this->assentos, false);
		return $disponiveis;
	}//mostrarAssentosDisponiveis

	public function calcularHorarioEmbarque(Viagem $viagem){
		$xerox = $viagem->get("horaPartida");
		$embarque = $xerox->sub(new DateInterval('PT'.INTERVALO_EMBARQUE.'M'));
		return $embarque;
	}//calcularHorarioEmbarque
	
	/*
	public function exibirTotalAssentosEmbarque($viagens){
		for($i = 0; $i<sizeof($viagens); $i++){
			$valorTotal = $viagens[$i]->get("voo")->get("tarifa");
			$embarque = 
			echo("Valor Total: ".$valorTotal." reais");
			echo("Horário de Embarque: ".$embarque);
			echo("Assentos Disponíveis: ".);
		}
	}
	*/
	
	static public function pesquisarViagem(string $origem, string $destino, datetime $data, int $numPassageiros){
		$viagensCadastradas = Viagem::getRecordsByField("dataViagem",$data);//retorna as viagens daquela data
		$voos = Voo::pesquisarVoos($origem, $destino);//retorna os voos com esse caminho
		$compativeis = array();
		if(!empty($voos)){
			for($i = 0; $i < sizeof($viagensCadastradas); $i++){
				$totalViajantes = sizeof($viagensCadastradas[$i]->get("viajantes"));
				$capAviao = $viagensCadastradas[$i]->get("aeronave")->get("capPassageiro");
				$num = $capAviao - $totalViajantes;

				for($j = 0; $j < sizeof($voos); $j++){
					if(($viagensCadastradas[$i]->get("voo")->get("codigoVoo") == $voos[$j]->get("codigoVoo")) && 
					   $num >= $numPassageiros){
					
						$compativeis[] = $viagensCadastradas[$i];
					}//if
				}//j
			}//i
			return $compativeis;
		}//if vazio
		else{
			$conexoes = Voo::criarConexao($origem, $destino);
			for($i = 0; $i<sizeof($conexoes); $i++){
				Viagem::pesquisarViagemConexao($conexoes[$i], $data, $numPassageiros);
			}//for
			return $conexoes;
		}//else	
	}//pesquisarViagem

	static private function pesquisarViagemConexao(Conexao &$conexao, datetime $data, int $numPassageiros){
		$vooPartida = $conexao->get("vooPartida");
		$vooChegada = $conexao->get("vooChegada");
		
		$aeroportoOrigem = $vooPartida->get("aeroportoPartida")->get("sigla");
		$aeroportoDestino = $vooPartida->get("aeroportoChegada")->get("sigla");
		
		$viagensPartida = Viagem::pesquisarViagem($aeroportoOrigem, $aeroportoDestino, $data, $numPassageiros);

		$aeroportoOrigem = $vooChegada->get("aeroportoPartida")->get("sigla");
		$aeroportoDestino = $vooChegada->get("aeroportoChegada")->get("sigla");
		
		$viagensChegada = Viagem::pesquisarViagem($aeroportoOrigem, $aeroportoDestino, $data, $numPassageiros);

		$conexao->set("viagensPartida", $viagensPartida);
		$conexao->set("viagensChegada", $viagensChegada);
	}//pesquisarViagemConexao
	
    public function pontuarPassageiros(){ #PERCORRENDO O ARRAY.
    	for($i = 0; $i < sizeof($this->viajantes); $i++){
			$passageiro = $this->viajantes[$i]->get("passageiro");
    		if($this->viajantes[$i]->get("statusPassageiro") == StatusPassageiro::EMBREALIZADO){
				$tipoPassageiro = get_class($passageiro);
				if($tipoPassageiro == "PassageiroVip"){
					$passageiro->setPontuacaoVigente($this->pontuacaoConcedida);
					ProgramaMilhagem::fazerUpgrade($passageiro);
				}//if se o passageiro é vip
        	}//if se embarcou
      	}//for
    }//pontuarPassageiro

    public function calcularMulta($passageiro){
    	$tipoPassageiro = get_class($passageiro);
      	 if($tipoPassageiro == "Passageiro"){
			 return $this->multa;
		 }
		 else if($tipoPassageiro == "PassageiroVip"){
			 $compViagem = $this->get("voo")->get("companhiaAerea")->get("codCompanhia");
			 $compPass = $passageiro->get("programaFavorito")->get("companhiaAerea")->get("codCompanhia");
			 if($compViagem == $compPass)
				 return 0;
			 else
				 return $this->multa;
		 }//else passageiroVip
		 else{
			 return null;
		 }
    }//calcularMulta

	public function calcularRessarcimento($passageiro, bool $precisaPagarMulta){
		$total = $this->voo->get("tarifa");
		if($precisaPagarMulta){
			$multa = $this->calcularMulta($passageiro);
			return $total - $multa;
		}
		else
			return $total;
	}//calcularRessarcimento

	public function executarViagem(DateTime $horaChegadaEfetiva){
		$this->horaChegada = $horaChegadaEfetiva;
		$this->pontuarPassageiros();
		$this->voo->armazenarViagem($this);
	}//executarViagem
	
}//clas