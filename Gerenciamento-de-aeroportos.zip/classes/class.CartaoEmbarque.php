 <?php
  include_once("../global.php");
  class CartaoEmbarque extends persist{
    private string $nomePassageiro;
    private string $sobrenomePassageiro;
    private string $aeroportoOrigem;
    private string $aeroportoDestino;
	private string $assento;
	
	private datetime $horarioPartida;
    private datetime $horarioEmbarque;
    

    //**********###############**********
    //##########Class functions##########
    //**********###############**********
    
	static public function getFilename(){
    	return "CartaoEmbarque.txt";
   	}//getFilename
	  
    public function __construct(string $p_nome, string $p_sobrenome, string $p_aeroportoOrigem, string $p_aeroportoDestino, string $p_assento, datetime $p_horaPartida, datetime $p_horaEmbarque){
      if (!(Usuario::checaLogin())) return;
      $this->nomePassageiro = $p_nome;
      $this->sobrenomePassageiro = $p_sobrenome;
      $this->aeroportoOrigem = $p_aeroportoOrigem;
      $this->aeroportoDestino = $p_aeroportoDestino;
	  $this->assento = $p_assento;
	  $this->horarioPartida = $p_horaPartida;
      $this->horarioEmbarque = $p_horaEmbarque;
     
    }//construct

	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set
	  
}//class
