<?php
include_once("../global.php");

class Coordenadas extends persist {
	private float $latitude;
	private float $longitude;
	
	//**********###############**********//
    //##########Class functions##########//
    //**********###############**********//
    
	static public function getFilename(){
    	return "Coordenadas.txt";
   	}//getFilename
	
  	public function __construct(float $p_lat, float $p_long) {
		if (!(Usuario::checaLogin())) return;
		$this->latitude = $p_lat;
		$this->longitude = $p_long;
	}//construct
	
	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set

	//calcula a distancia em Km
	static public function calcularDistancia(Coordenadas $cod1, Coordenadas $cod2) {
    	# implementar com API do Google futuramente
    	$lat = deg2rad($cod2->get("latidude") - $cod1->get("latidude"));
    	$long = deg2rad($cod2->get("longitude") - $cod1->get("longitude"));
    	$t = sin($lat/2) * sin($lat/2) + cos(deg2rad($cod1->get("latidude"))) * cos(deg2rad($cod2->get("latidude"))) * sin($long/2) * sin($long/2);
    	$l = 2 * atan2(sqrt($t), sqrt(1-$t));
    	$distancia = 6371 * $l;
    
    	return $distancia;
	}//calcularDistancia

	static public function converterEndereco(int $cep) {//da um numero aleatorio
                    
    	$lat = rand(-900000000, 900000000);
    	$long = rand(-1800000000, 1800000000); 
    
    	$lat = ($lat/100000)*($cep%1000);
    	$long = ($long/1000000)*($cep%1000);
    
    	while($lat > 90) {
      		$lat = $lat/2;
    	}//while
    	while($long > 180) {
      		$long = $long/2;
    	}//while

    	$coordenada = new Coordenadas($lat, $long);
    	return $coordenada;
  	}//converterEndereco

}//class