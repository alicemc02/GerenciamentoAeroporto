<?php
include_once("../global.php");
define('ANTECEDENCIA_CRIACAO_VIAGEM', 30);//dias

  class Voo extends persist{
	private string $codigoVoo; //concatenação de companhia aerea e 
  	private int $codVoo; //parte numeral //qual a utilidade?
    private int $duracaoEstimada;//em minutos
	private float $tarifa;
	  
  	private DateTime $horarioPartida;
    
	private Aeroporto $aeroportoPartida;
    private Aeroporto $aeroportoChegada;
  	private Aeronave $aeronave;
	private CompanhiaAerea $companhiaAerea;
	  
    private $frequenciaSemanal = array(
        "Domingo" => false,
        "Segunda" => false,
        "Terça"   => false,
        "Quarta"  => false,
        "Quinta"  => false,
        "Sexta"   => false,
        "Sábado"  => false,
      );
    private $regViagem;//array de viagem
    private $datasViagensFuturas;//array de datetime
	private $viagensFuturas;//array de viagens
    //**********###############**********
    //##########Class functions##########
    //**********###############**********

	 static public function getFilename(){
		return "Voo.txt";
   	}//getFilename
    
    public function __construct(CompanhiaAerea $p_companhiaAerea, Aeroporto $p_partida, Aeroporto $p_chegada, DateTime $p_horarioPartida, int $p_duracaoEstimada) {
      if (!(Usuario::checaLogin())) return;
      $this->companhiaAerea = $p_companhiaAerea;
      $this->aeroportoPartida = $p_partida;
      $this->aeroportoChegada = $p_chegada;
      $this->horarioPartida = $p_horarioPartida;
      $this->duracaoEstimada = $p_duracaoEstimada;
	  $this->regViagem = array();
	  $this->datasViagensFuturas = array();
	  $this->viagensFuturas = array();
      echo "Voo cadastrado com sucesso!";
	  echo "\n";
    }//construct
	  
	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set 
	  
	public function setCodigoVoo (string $p_codigo){              
        echo "Realizando o cadastro de código do voo $p_codigo...";
        echo "\n";
      	$padrao = "/[A-Z]{2}-\d{4}$/";//cria padrão esperado para o código: Duas letras, um hífen e 4 números
      	$codigoMaiusculo = strtoupper($p_codigo);// transforma a sigla em letras maiúsculas                                               
      	if (preg_match($padrao, $codigoMaiusculo)){//testa se o código enviado está de acordo com o padrão
        	$siglaCodigo = substr($codigoMaiusculo, 0, 2);// retorna apenas as duas primeiras letras do código
          if($siglaCodigo == $this->companhiaAerea->get("siglaComp")){ //testa se a sigla da companhia é igual a enviada
            	$this->codigoVoo = $codigoMaiusculo;
              echo "Código $codigoMaiusculo cadastrado com sucesso!";                                                           
          	} else{
                echo "O código $codigoMaiusculo tem a sigla divergente da companhia. Realizando ajuste...";
                $codigoMaiusculo = preg_replace("/^[A-Z]{2}/", $this->companhiaAerea->get("siglaComp"), $codigoMaiusculo);
                $this->codigoVoo = $codigoMaiusculo;
                echo "\n";
                echo "O código atualizado é o $codigoMaiusculo. Código atualizado e cadastrado com sucesso!";
                
            }//else
      	} else{
          echo "O código $p_codigo não está de acordo com o padrão esperado. Realizando ajuste...";
          echo "\n";
          $novoCodigo = substr_replace($p_codigo, '-', 2, 0);
          $this->setCodigoVoo($novoCodigo);                    //envia código para ser analisado novamente
      	}//else
    }//setCodigoVoo
    
    public function setFrequenciaSemanal(string $p_dia, bool $p_tVoo){
      	$this->frequenciaSemanal[$p_dia] = $p_tVoo;
    }//setFreqSemanal
	  
    public function armazenarViagem (Viagem $p_viagem) {
      array_push($this->regViagem, $p_viagem);
    }//armazenarViagem

	public function salvarDatasFuturas(){
		for($i = 1; $i<=ANTECEDENCIA_CRIACAO_VIAGEM; $i++){
    		$dia = "";
      		$salvaHorario = new DateTime();
      		$diaLimiteVoo = $salvaHorario->modify($i." days");
			$xerox = clone $diaLimiteVoo;//para preservar o datetime alterado
      		$diaLimiteVoo = $diaLimiteVoo->format('d-m-Y');
      		$diaSemana = date('w',strtotime($diaLimiteVoo));
      		switch($diaSemana){
        		case 0:
          			$dia = "Domingo";          
        			break;
        
        		case 1:
          			$dia = "Segunda";
        			break;

        		case 2:
          			$dia = "Terça";
        			break;
		  
       	 		case 3:
          			$dia = "Quarta";          
        			break;
        
        		case 4:
          			$dia = "Quinta";
        			break;

        		case 5:
          			$dia = "Sexta";
        			break;
		  
        		case 6:
          			$dia = "Sábado";
					break;
      		}//switch
       		// Analisa se o dia que vence a marcação de viagem terá voos, se sim, esse poderá ser o último dia.
      		if($this->frequenciaSemanal[$dia] == true){
        		$this->datasViagensFuturas[] = $xerox;
        	}//if   
		}//for
    }//salvarDatasFuturas

	public function criarViagensFuturas(){
		$this->salvarDatasFuturas();
		for($i = 0; $i<sizeof($this->datasViagensFuturas); $i++){
			$data = $this->datasViagensFuturas[$i];
			$this->viagensFuturas[$i] = new Viagem($data, $this->aeronave, $this);
		}
	}//criarViagensFuturas

  	static function pesquisarVoos(string $aeroporto_partida, string $aeroporto_chegada){
    
    	$save=Voo::getRecords();
    	$voos_compativeis = array();
    	for( $i = 0; $i < sizeof($save); $i++){ #PERCORRENDO O ARRAY.
        	$recebe_partida = $save[$i]->get("aeroportoPartida")->get("sigla");                     
        	$recebe_chegada = $save[$i]->get("aeroportoChegada")->get("sigla");                       
												
      		if(($recebe_partida == $aeroporto_partida) && 
         	($recebe_chegada == $aeroporto_chegada)){
        
        		$voos_compativeis[] = $save[$i];
      		}//if
    	}//for
		return $voos_compativeis;
  	}//pesquisarVoos

 	static function criarConexao(string $aeroporto_partida, string $aeroporto_chegada){
  
		$partidaOficial = array();
		$chegadaOficial = array();
		$conexao = array();
		$voo = Voo::getRecords();
		 
		for($i = 0; $i<sizeof($voo); $i++){
			if($voo[$i]->get("aeroportoPartida")->get("sigla") == $aeroporto_partida)
				$partidaOficial[] = $voo[$i];
		}//for partidaOficial
		for($i = 0; $i<sizeof($voo); $i++){
			if($voo[$i]->get("aeroportoChegada")->get("sigla") == $aeroporto_chegada)
				$chegadaOficial[] = $voo[$i];
		}//for chegadaOficial

		for($i = 0; $i<sizeof($partidaOficial); $i++){
			for($j = 0; $j<sizeof($chegadaOficial); $j++){
				if($partidaOficial[$i]->get("aeroportoChegada")->get("sigla") == 
				   $chegadaOficial[$j]->get("aeroportoPartida")->get("sigla")){
					
					$conexao[] = new Conexao($partidaOficial[$i], $chegadaOficial[$j]);
				}//if
			}//for j
		}//for i
		return $conexao;
  	}//criarConexao
	  
}//class