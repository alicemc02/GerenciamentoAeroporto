<?php
  include_once("../global.php");

  class Voo extends persist{

	private string $codigoVoo; //concatenação de companhia aerea e 
  	private int $codVoo; //parte numeral //qual a utilidade?
    private int $duracaoEstimada;
	private float $tarifa;
  	private DateTime $horarioPartida;
    
	private Aeroporto $aeroportoPartida;
    private Aeroporto $aeroportoChegada;
  	private Aeronave $aeronave;
	private CompanhiaAerea $companhiaAerea;
	  
    private $frequenciaSemanal = array(
        "Domingo" => false,
        "Segunda" => false,
        "Terça"   => false,
        "Quarta"  => false,
        "Quinta"  => false,
        "Sexta"   => false,
        "Sábado"  => false,
      );
    private $regViagem = array();//viagem
    private $datasViagensFuturas = array();//datetime

    //**********###############**********
    //##########Class functions##########
    //**********###############**********

	 static public function getFilename(){
		return "Voo.txt";
   	}//getFilename
    
    public function __construct(CompanhiaAerea $p_companhiaAerea, Aeroporto $p_partida, Aeroporto $p_chegada, DateTime $p_horarioPartida, int $p_duracaoEstimada) {
      if (!(Usuario::checaLogin())) return;
      $this->companhiaAerea = $p_companhiaAerea;
      $this->aeroportoPartida = $p_partida;
      $this->aeroportoChegada = $p_chegada;
      $this->horarioPartida = $p_horarioPartida;
      $this->duracaoEstimada = $p_duracaoEstimada;
      echo "Voo cadastrado com sucesso!";
      echo "\n";
    }
	  
	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set
	  
	public function setCodigoVoo (string $p_codigo){              
        echo "Realizando o cadastro de código do voo $p_codigo...";
        echo "\n";
      	$padrao = "/[A-Z]{2}-\d{4}$/";//cria padrão esperado para o código: Duas letras, um hífen e 4 números
      	$codigoMaiusculo = strtoupper($p_codigo);// transforma a sigla em letras maiúsculas                                               
      	if (preg_match($padrao, $codigoMaiusculo)){//testa se o código enviado está de acordo com o padrão
        	$siglaCodigo = substr($codigoMaiusculo, 0, 2);// retorna apenas as duas primeiras letras do código
          if($siglaCodigo == $this->companhiaAerea->get("siglaComp")){ //testa se a sigla da companhia é igual a enviada
            	$this->codigoVoo = $codigoMaiusculo;
              echo "Código $codigoMaiusculo cadastrado com sucesso!";                                                           
          	} else{
                echo "O código $codigoMaiusculo tem a sigla divergente da companhia. Realizando ajuste...";
                $codigoMaiusculo = preg_replace("/^[A-Z]{2}/", $this->companhiaAerea->get("siglaComp"), $codigoMaiusculo);
                $this->codigoVoo = $codigoMaiusculo;
                echo "\n";
                echo "O código atualizado é o $codigoMaiusculo. Código atualizado e cadastrado com sucesso!";
                
            }//else
      	} else{
          echo "O código $p_codigo não está de acordo com o padrão esperado. Realizando ajuste...";
          echo "\n";
          $novoCodigo = substr_replace($p_codigo, '-', 2, 0);
          $this->setCodigoVoo($novoCodigo);                    //envia código para ser analisado novamente
      	}//else
    }//setCodigoVoo
    
    public function setFreqSemanal(string $p_dia, bool $p_tVoo){
      	$this->frequenciaSemanal[$p_dia] = $p_tVoo;
    }//setFreqSemanal
	  
    public function armazenarViagem (Viagem $p_viagem) {
      array_push($this->regViagem, $p_viagem);
    }//armazenarViagem

	public function salvarDiaLimite(){
    	$dia = "";
      	$salvaHorario = new DateTime();
      	$diaLimiteVoo = $salvaHorario->modify("30 days");
      	$diaLimiteVoo = $diaLimiteVoo->format('d-m-Y');
      	$diaSemana = date('w',strtotime($diaLimiteVoo));
      	switch($diaSemana){
        	case 0:
          		$dia = "Domingo";          
        		break;
        
        	case 1:
          		$dia = "Segunda";
        		break;

        	case 2:
          		$dia = "Terça";
        		break;
		  
       	 	case 3:
          		$dia = "Quarta";          
        		break;
        
        	case 4:
          		$dia = "Quinta";
        		break;

        	case 5:
          		$dia = "Sexta";
        		break;
		  
        	case 6:
          		$dia = "Sábado";
				break;
      	}//switch
       
      	if($this->frequenciaSemanal[$dia] == true){// Analisa se o dia que vence a marcação de viagem terá voos, se sim, esse poderá ser o último dia.
        	$this->datasViagensFuturas[] = $diaLimiteVoo;
        }//if    
    }//salvarDiaLimite

  	static function pesquisarVoos(string $aeroporto_partida, string $aeroporto_chegada){
    
    	$save=Voo::getRecords();
    	$voos_compativeis = array();
    	for( $i = 0; $i < sizeof($save); $i++){ #PERCORRENDO O ARRAY.
        	$recebe_partida = $save[$i]->get("aeroportoPartida")->get("sigla");                     
        	$recebe_chegada = $save[$i]->get("aeroportoChegada")->get("sigla");                       
												
      		if(($recebe_partida == $aeroporto_partida) && 
         	($recebe_chegada == $aeroporto_chegada)){
        
        		$voos_compativeis[] = $save[$i];
      		}//if
    	}//for
      if(empty($voos_compativeis)) {
        return Voo::criarConexao($aeroporto_partida, $aeroporto_chegada);
      }
		return $voos_compativeis;
  	}//pesquisarVoos

 	 static function criarConexao(string $aeroporto_partida, string $aeroporto_chegada){
  	# nao tem como pegar voo direto
  	# pegar o ger records(pega todos os voos que estao guardados)
   	# comparar dois arrays iguais (funcao do php)
  	# pesquisa pelo valor com a chave
    	# Chave-> aer partida e aer chegada
  	# Valores-> Confere se os valores dessas chaves sao iguais
  	# Ver quais voos que estão chegando e saindo do aeroporto
  	# Todas as partidas de guarulhos e com base nessas chegadas, buscar novamente quais chegadas são partidas

  	$vooArray = Voo::getRecords();
   	$partida1 = array();
  	$chegada1 = array();
  	$partida2 = array();
  	$chegada2 = array();
   
   	$passagem1 = array($partida1, $chegada1);
   	$passagem2 = array($partida2, $chegada2);
   
  	for($i = 0; $i <= sizeof($vooArray); $i++) { 
      	for($j = 0; $j <= sizeof($vooArray); $j++) {
        	if($vooArray[$i]->get("aeroportoPartida")->get("sigla") == $aeroporto_partida &&
           	$vooArray[$i]->get("aeroportoChegada")->get("sigla") == $vooArray[$j]->get("aeroportoPartida")->get("sigla") && $vooArray[$j]->get("aeroportoChegada")->get("sigla") == $aeroporto_chegada
             )
           {
            $passagem1 = array($vooArray[$i], $vooArray[$i]);
            $passagem2 = array($vooArray[$i], $vooArray[$j]);
        	}//if     
      	}//for j
    }//for i
    return array($passagem1,$passagem2);//retorna array de aeroportos
  }//criarConexao
	  
}//class