<?php
	include_once("../global.php");
  class Aeroporto extends persist{
    private string $sigla;
    private string $cidade;
    private string $estado;
	private Coordenadas $coordenadas;
    //**********###############**********
    //##########Class functions##########
    //**********###############**********
    static public function getFilename(){
    	return "Aeroporto.txt";
   	}//getFilename
		
    public function __construct(string $p_sigla, string $p_cidade, string $p_estado, Coordenadas $p_coor){
          if (!(Usuario::checaLogin())) return;
          $this->sigla = $this->verificarSigla($p_sigla);
          $this->cidade = $p_cidade;
          $this->estado = $p_estado;
		$this->coordenadas = $p_coor;
          echo "Aeroporto cadastrado com sucesso!";
          echo "\n";
      }//construct
		
    public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set
		
	public function setSigla(string $p_novaSigla){
    	$this->sigla = $this->verificarSigla($p_novaSigla);
    }//setSigla

	public function verificarSigla(string $p_sigla){
		$siglaUp = strtoupper($p_sigla); // transforma a sigla em letras maiúsculas
        
       if(strlen($siglaUp) === 3 && ctype_alpha($siglaUp)){
		   //testa se a sigla possui três letras e se todos os caracteres são, de fato, letras.
		   return $siglaUp;
	   }//if
		else{
            throw(new Exception('A sigla fornecida precisa ter, necessariamente, 3 letras.'));
        }//else
	}//verificarSigla
		
}//class