<?php
include_once("../global.php");

class Rota extends persist {
  	private $enderecosVisitados;//coordenadas
 
	static public function getFilename(){
    	return "Rota.txt";
   	}//getFilename
	
  	public function __construct($p_coordenadas){
		if (!(Usuario::checaLogin())) return;
		$this->enderecosVisitados = $p_coordenadas;
	}//construct
	
	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set
	
}//class