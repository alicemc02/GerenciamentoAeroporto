<?php

include_once("../global.php");

class PassageiroVip extends Passageiro {
	private int $pontuacaoVigente;
	private int $pontuacaoAcumulada;

	private $regPontuacao = array();//<datetime,int>
	private ProgramaMilhagem $programaFavorito;
	private CategoriaPrograma $categoriaVigente;
	
	//**********###############**********
    //##########Class functions##########
    //**********###############**********
	
	static public function getFilename(){
    	return "PassageiroVip.txt";
   	}//getFilename

	public function __construct(string $p_nome, string $p_sobrenome, string $p_documento, int $p_cpf, string $p_nacionalidade, datetime $p_dataNasc, string $p_email) {
    	if (!(Usuario::checaLogin())) return;
    	parent::__construct($p_nome, $p_sobrenome, $p_documento, $p_cpf, $p_nacionalidade, $p_dataNasc, $p_email);
  	}//construct
	
	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set
	
	public function setPontuacaoVigente(int $novaPontuacao){
		$this->pontuacaoVigente += $novaPontuacao;
    	$regPontuacao[date('d-m-y h:i:s')] = $novaPontuacao;
    	$this->pontuacaoAcumulada += $novaPontuacao;
	}//setPontuacaoVigente

	public function setRegPontuacao(datetime $novaData, int $novoPonto){
		$this->regPontuacao[$novaData] = $novoPonto;
	}//setRegPontuacao

  	public function verificarCompanhiaPassageiroVip(CategoriaPrograma $novaCategoriaVigente){
	}//verificarCompanhiaPassageiroVip

  	public function calcularBagagem(){
    
  		$precoBagagem = $this->passagem->get("viagem")->get("voo")->get("companhiaAerea")->get("precoBagagem");
  		$pesoBagagem= $this->passagem->get("bagagem");
  		$aux=0;
      	for($i=0; $i < sizeof($pesobagagem); $i++){
        	if($pesobagagem[$i] != 0){
        		$aux++;
        	}//if
      	}//for
		return $aux * $precoBagagem;

    	if( $aux == 1){
      		return 0;
    	}
    	else if( $aux == 2){
      		return  ( $precoBagagem * 0.5 );
    	}
    	else if ($aux == 3){
      		return $precoBagagem;
    	}
  
	}//calcularBagagem

  	public function vencerPontuacaoVigente(){
    	//if($ultimaModificacao)
    }//vencerPontuacaoVigente

}//class