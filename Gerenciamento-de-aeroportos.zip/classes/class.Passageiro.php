<?php
include_once("../global.php");

class Passageiro extends Pessoa{
	private $passagensPassadas;//array de passagens
	
 	//**********###############**********
    //##########Class functions##########
    //**********###############**********

  	static public function getFilename(){
    	return "Passageiro.txt";
   }//getFilename
	public function __construct(string $p_nome, string $p_sobrenome, string $p_documento, int $p_cpf, string $p_nacionalidade, datetime $p_dataNasc, string $p_email){
    	if (!(Usuario::checaLogin())) return;
    	parent::__construct($p_nome,$p_sobrenome,$p_documento,$p_cpf,$p_nacionalidade,$p_dataNasc,$p_email);
		$this->voosPassados = array();
  	}//construct
	
	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set
	
	public function setVoosPassados(Voo $novoVoo){
		array_push($this->voosPassados,$novoVoo);
	}//setVoosPassados
	
	public function calcularBagagem(Passagem $pass){
  		$precoBagagem = $pass->get("viagem")->get("voo")->get("companhiaAerea")->get("precoBagagem");
  		$pesoBagagem = $pass->get("bagagem");
  		$aux=0;
      	for($i=1; $i < sizeof($pesoBagagem); $i++){
        	if($pesoBagagem[$i] != 0){
        		$aux++;
        	}//if
      	}//for
		return $aux * $precoBagagem;
  	}//calcularBagagem	

	static function pesquisarPassageiro(string $nome, string $sobrenome){
  		$save = Passageiro::getRecords();
  		for($i = 0; $i < sizeof($save); $i++){
    		$recebeNome = $save[$i]->get("nome");
    		$recebeSobrenome = $save[$i]->get("sobrenome");
    		if(($recebeNome == $nome) && ($recebeSobrenome == $sobrenome)){
      			return $save[$i];
    		}//if
  		}//for
	}//pesquisarPassageiro
	
}//class