<?php

include_once("../global.php");
include_once("StatusPassageiro.php");

define('PESO_MAXIMO',23);//Kg
define('INTERVALO_ALTERACAO',4);//horas
define('HORARIO_MINIMO_CHECKIN',48);//horas
define('HORARIO_MAXIMO_CHECKIN',30);//minutos
define('INTERVALO_EMBARQUE', 40);//minutos

class Passagem extends persist{ 
  	private float $precoPassagem;
  	private string $assentoReservado;
  	private DateTime $dataCompra;
	
	private Passageiro $passageiro;
	private StatusPassageiro $statusPassageiro;
	private Cliente $comprador;
	
	private $viagem;
	private $cartaoEmbarque;
	private $bagagem;
	
	
    //**********###############**********//
    //##########Class functions##########//
    //**********###############**********//
    
	static public function getFilename(){
    	return "Passagem.txt";
   	}//getFilename
	
  	public function __construct($p_viagem, Passageiro $p_passageiro, Cliente $p_comprador){
      if (!(Usuario::checaLogin())) return;
		$this->viagem = $p_viagem;     
    	//$this->assentoReservado = $p_assentoReservado;
    	$this->dataCompra = new DateTime();   
		$this->passageiro = $p_passageiro;
		$this->comprador = $p_comprador;
		$this->cartaoEmbarque = array();
		$this->bagagem = array(
    		1 => 0.0,
      		2 => 0.0,
      		3 => 0.0,
    	);
  	}//construct

	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set
	
  	public function setBagagem(float $p_bagagem1, float $p_bagagem2, float $p_bagagem3){
		$testaBagagem1 = ($p_bagagem1 >= 0) && ($p_bagagem1 <= PESO_MAXIMO);
		$testaBagagem2 = ($p_bagagem2 >= 0) && ($p_bagagem2 <= PESO_MAXIMO);
		$testaBagagem3 = ($p_bagagem3 >= 0) && ($p_bagagem3 <= PESO_MAXIMO);
    	if($testaBagagem1 && $testaBagagem2 && $testaBagagem3){    //testa se as bagagens tem 23kg ou menos
      		$this->bagagem[1] = $p_bagagem1;
      		$this->bagagem[2] = $p_bagagem2;
      		$this->bagagem[3] = $p_bagagem3;
    	}else{
      		throw(new Exception('O peso das bagagens devem ser iguais ou inferiores a '.PESO_MAXIMO.'kg. Por favor, revise a carga'));
    	}//else
  	}//setBagagem
	
	
	static public function comprarPassagem(Cliente $comprador, string $nomeViajante, string $sobrenomeViajante, string $origem, string $destino, datetime $data){
		$escolhaViagem = 0;//temporario, define a escolha do usuario
		$escolhaConexao = 0;
		$escolhaViagemConexao1 = 0;
		$escolhaViagemConexao2 = 0;
		
		$passageiro = Passageiro::pesquisarPassageiro($nomeViajante, $sobrenomeViajante);
		if($passageiro == null)
			$passageiro = PassageiroVip::pesquisarPassageiro($nomeViajante, $sobrenomeViajante);
		$viagens = Viagem::pesquisarViagem($origem, $destino, $data, 1);
		$tipoClasse = get_class($viagens[0]);
		
		if($tipoClasse == "Viagem"){
			$passagem = new Passagem($viagens[$escolhaViagem], $passageiro, $comprador);
		}//if viagem
		else if($tipoClasse == "Conexao"){
			$viagensPartida = $viagens[$escolhaConexao]->get("viagensPartida");
			$viagensChegada = $viagens[$escolhaConexao]->get("viagensChegada");
			$viagensConexao = array($viagensPartida[$escolhaViagemConexao1], $viagensChegada[$escolhaViagemConexao2]);
			$passagem = new Passagem($viagensConexao, $passageiro, $comprador);
		}//if conexao
		$passagem->statusPassageiro = StatusPassageiro::PASADQUIRIDA;
		return $passagem;
  	}//comprarPassagem

	public function calcularTotal(){
		if(is_array($this->viagem)){
			for($i = 0; $i<sizeof($this->viagem); $i++){
				$tarifaVoo += $this->viagem[$i]->get("voo")->get("tarifa");
			}//for
		}//if
		else{
			$tarifaVoo = $this->viagem->get("voo")->get("tarifa");
		}//else
		$bagagem = $this->passageiro->calcularBagagem($this);
		$precoTotal = $tarifaVoo + $bagagem;
		$this->precoPassagem = $precoTotal;
	}//calcularTotal
	
  	public function cancelarPassagem(){
		$this->viagem->setAssentoFalse($this->assentoReservado);
		//coloca 'false' no assento reservado previamente na Viagem
    	$this->statusPassageiro = StatusPassageiro::PASCANCELADA;
		$pagamento = $this->viagem->calcularRessarcimento($this->passageiro, true);
		echo("Valor de ressarcimento: ".$pagamento." reais");
  	}//cancelarPassagem
    
	public function alterarPassagem(string $atributoParaAlterar, $novoValorAtributo){
		$horaAlteracao = new DateTime();
		$primeiraViagem;
		if(is_array($this->viagem))
			$primeiraViagem = $this->viagem[0];
		else
			$primeiraViagem = $this->viagem;
		
		$horaPartida = $primeiraViagem->get("horaPartida");
		$horaXerox = $horaPartida;
		$quatroHorasAntes = $horaXerox->sub(new DateInterval('PT'.INTERVALO_ALTERACAO.'H'));
		
		if($horaAlteracao <= $quatroHorasAntes){
			$this->set($atributoParaAlterar, $novoValorAtributo);
			$multa = $primeiraViagem->calcularMulta($this->passageiro);
			echo("O valor da multa é ".$multa." reais");
		}
		else{
			throw(new Exception("Alteração realizada fora do horário permitido"));
		}
	}//alterarPassagem
	
  	public function fazerCheckin(Datetime $dataPartida){
		if($this->statusPassageiro == StatusPassageiro::PASADQUIRIDA){
			$dataXerox1 = clone $dataPartida;
			$dataXerox2 = clone $dataPartida;
			$horaCheckin = new DateTime();
			//Faz o xerox para não modificar a data original
			$doisDiasAntes = $dataXerox1->sub(new DateInterval('PT'.HORARIO_MINIMO_CHECKIN.'H'));
			$meiaHoraAntes = $dataXerox2->sub(new DateInterval('PT'.HORARIO_MAXIMO_CHECKIN.'M'));

			if($horaCheckin >= $doisDiasAntes && $horaCheckin <= $meiaHoraAntes){
				$this->statusPassageiro = StatusPassageiro::CHEKREALIZADO;
  				$this->gerarCartaoEmbarque();
			}//if intervalo
			else{
				throw(new Exception("Checkin realizado fora do horário permitido"));
			}
		}//if passagem adquirida
  	}//fazerCheckin

	public function fazerEmbarque(bool $embarqueRealizado){
		if($embarqueRealizado)
			$this->statusPassageiro = StatusPassageiro::EMBREALIZADO;
		else
			$this->statusPassageiro = StatusPassageiro::NOSHOW;
	}//fazerEmbarque
	
    public function gerarCartaoEmbarque(){
		$nome = $this->passageiro->get("nome");
		$sobrenome = $this->passageiro->get("sobrenome");
		
		if(is_array($this->viagem)){
			for($i = 0; $i < sizeof($this->viagem); $i++){
				$aeropOrigem = $this->viagem[$i]->get("voo")->get("aeroportoPartida")->get("sigla");
				$aeropDestino = $this->viagem[$i]->get("voo")->get("aeroportoChegada")->get("sigla");
				$horaPartida = $this->viagem[$i]->get("horaPartida");
				$horaXerox = clone $horaPartida;
				$horaEmbarque = $horaXerox->sub(new DateInterval('PT'.INTERVALO_EMBARQUE.'M'));
				$assento = $this->assentoReservado;
				$this->cartaoEmbarque[$i] = new CartaoEmbarque($nome, $sobrenome, $aeropOrigem, $aeropDestino, $assento, $horaPartida, $horaEmbarque);
			}//for
		}//if se tiver mais de uma viagem
		else{
			$aeropOrigem = $this->viagem->get("voo")->get("aeroportoPartida")->get("sigla");
			$aeropDestino = $this->viagem->get("voo")->get("aeroportoChegada")->get("sigla");
			$horaPartida = $this->viagem->get("horaPartida");
			$horaXerox = clone $horaPartida;
			$horaEmbarque = $horaXerox->sub(new DateInterval('PT'.INTERVALO_EMBARQUE.'M'));
			$assento = $this->assentoReservado;
			$this->cartaoEmbarque = new CartaoEmbarque($nome, $sobrenome, $aeropOrigem, $aeropDestino, $assento, $horaPartida, $horaEmbarque);
			//var_dump($this->cartaoEmbarque);
		}//else
		
    }//gerarCartaoEmbarque
	
}//class