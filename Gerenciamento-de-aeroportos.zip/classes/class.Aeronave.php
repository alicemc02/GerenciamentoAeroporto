<?php

include_once("../global.php");
include_once("TipoSigla.php");
define("TAMANHO_CODIGO", 3);//letras

class Aeronave extends persist{
    private string $fabricante;
    private string $modelo;
	private string $regAeronave;
	  
    private int $capPassageiro;
    private int $velMaxima;//????????????????????????????????????????????????????
    private float $capCarga;
    private CompanhiaAerea $companhiaAerea;

    //**********###############**********
    //##########Class functions##########
    //**********###############**********
    
	static public function getFilename(){
    	return "Aeronave.txt";
   	}//getFilename
	  
    public function __construct (string $p_fabricante, string $p_modelo, CompanhiaAerea $p_companhiaAerea, int $p_capPassageiro, float $p_capCarga, int $p_velMaxima){
      if (!(Usuario::checaLogin())) return;
      $this->fabricante = $p_fabricante;
      $this->modelo = $p_modelo;
      $this->capPassageiro = $p_capPassageiro;
      $this->capCarga = $p_capCarga;
      $this->companhiaAerea = $p_companhiaAerea;
      $this->regAeronave = 'Indefinido';
      $this->velMaxima = $p_velMaxima;
    }//construct

	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set
	  
    public function setRegAeronave(string $p_sigla, string $p_codigo){
      echo "Realizando a inserção da sigla e do código fornecido..." ."\n";
      switch ($p_sigla) {
        case 'PT':
            $sigla = TipoSigla::PT;
            break;
        case 'PR':
            $sigla = TipoSigla::PR;
            break;
        case 'PP':
            $sigla = TipoSigla::PP;
            break;
        case 'PS':
            $sigla = TipoSigla::PS;
            break;
        default:
            echo "A sigla '$p_sigla' não está disponível para inserção. Por favor, tente novamente inserindo outra sigla!". "\n";
        return;
    }
      $tamanhoCodigo = strlen($p_codigo);
      $codigoMaiusculo = strtoupper($p_codigo);// transforma a sigla em letras maiúsculas
      
      if(($tamanhoCodigo != TAMANHO_CODIGO) & (ctype_alpha($codigoMaiusculo))){ //testa o requisito de tamanho de código e se há 3 caracteres e deve ser formado por 3 três letras
        throw(new Exception('O código fornecido precisa ser exatamente '.TAMANHO_CODIGO.' caracteres. Por favor, tente novamente!'));
      }//if
      
      $this->regAeronave = $sigla->name."-".$codigoMaiusculo;  //concatena sigla, hífen e codigo. Exemplo: "PT + (HIFEN) + XLR"
      echo "Registro de aeronave '$this->regAeronave' realizado com sucesso!". "\n";
    }//setRegAeronave


}//class