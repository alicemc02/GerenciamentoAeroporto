 <?php
  include_once("../global.php");
  class CartaoEmbarque extends persist{
    private string $nomePassageiro;
    private string $sobrenomePassageiro;
    private string $aeroportoOrigem;
    private string $aeroportoDestino;
    private datetime $horarioEmbarque;
    private datetime $horarioPartida;
    private string $assento;

    //**********###############**********
    //##########Class functions##########
    //**********###############**********
    
	static public function getFilename(){
    	return "CartaoEmbarque.txt";
   	}//getFilename
	  
    public function __construct(string $p_nome, string $p_sobrenome, string $p_origem, string $p_destino, datetime $p_embarque, string $p_partida, float $p_assento){
      if (!(Login::checaLogin())) return;//????????????????????
      $this->nomePassageiro = $p_nome;
      $this->sobrenomePassageiro = $p_sobrenome;
      $this->aeroportoOrigem = $p_origem;
      $this->aeroportoDestino = $p_destino;
      $this->horarioEmbarque = $p_embarque;
      $this->aeroportoPartida = $p_partida;
      $this->assento = $p_assento;
    }//construct

	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set
	  
}//class
