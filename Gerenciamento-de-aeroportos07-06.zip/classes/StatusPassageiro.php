<?php
  enum StatusPassageiro {
    case PASADQUIRIDA;
    case PASCANCELADA;
    case CHEKREALIZADO;
    case EMBREALIZADO;
    CASE NOSHOW;
  }
?>