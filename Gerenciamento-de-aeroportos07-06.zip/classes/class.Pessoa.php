<?php
include_once("../global.php");
abstract class Pessoa extends persist{

	protected string $nome;
	protected string $sobrenome;
	protected string $documento;
	protected string $nacionalidade;
	protected string $email;
	
	protected ?int $cpf;
	protected DateTime $dataNasc;
	
	//**********###############**********//
    //##########Class functions##########//
    //**********###############**********//
    
	static public function getFilename(){
    	return "Pessoa.txt";
   	}//getFilename
	
  public function __construct(string $p_nome, string $p_sobrenome, string $p_documento, int $p_cpf, string $p_nacionalidade, DateTime $p_dataNasc, string $p_email) {
      if (!(Login::checaLogin())) return;
    	$this->nome = $p_nome;
    	$this->sobrenome = $p_sobrenome; 
    	$this->documento = $p_documento;
	  	if(Pessoa::validarCPF($p_cpf, $p_nacionalidade)){
			$this->cpf = $p_cpf; 
    		$this->nacionalidade = $p_nacionalidade;
		}
    	if(Pessoa::validarEmail($p_email)){
			$this->email = $p_email;
		}
	  	if(Pessoa::validarDataNasc($p_dataNasc)){
			$this->dataNasc = $p_dataNasc;
		}
  	}//construct
	
	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set

	public function setEmail(string $novoEmail){
		if(Pessoa::validarEmail($novoEmail))
			$this->email = $novoEmail;
	}//setNome
	
	public function setCpf(int $novoCpf, string $nacionalidade){
		if(Pessoa::validarCpf($novoCpf, $nacionalidade))
			$this->cpf = $novoCpf;
	}//setCpf

	public function setDataNascimento(DateTime $novaData){
		if(Pessoa::validarDataNasc($novaData))
			$this->dataNascimento = $novaData;
	}//setDataNascimento

  	static protected function validarCPF(int $p_cpf, string $p_nacionalidade){
    	$multiplicadores_1 = array(10, 9, 8, 7, 6, 5, 4, 3, 2);
    	$multiplicadores_2 = array(11, 10, 9, 8, 7, 6, 5, 4, 3, 2);
    	$digito_1 = 0;
    	$digito_2 = 0;
    	$cpf = strval($p_cpf);  

    	if(!($p_nacionalidade == "BRASILEIRO")){
      		throw(new Exception("Nacionalidade inválida!"));
    	}//if
   		else{
      		if(strlen($cpf) == 11){
    			for($i = 0; $i < 9; $i++){
          			$digito_1 += ($cpf[$i] * $multiplicadores_1[$i]);
       			}//for
        		$resto_1 = $digito_1 % 11;
      			if(($resto_1 < 2 && $cpf[9] == 0) || ($resto_1 >= 2 && $cpf[9] == 11 - $resto_1)){
        			for($i = 0; $i < 10; $i++){
          				$digito_2 += ($cpf[$i] * $multiplicadores_2[$i]);
        			}//for
         			$resto_2 = $digito_2 % 11;
      				if(!(($resto_2 < 2 && $cpf[10] == 0) || ($resto_2 >= 2 && $cpf[10] == 11 - $resto_2))){
        				throw(new Exception("CPF inválido!"));
       				}//if cpf[10]
      			}//if cpf[9]
				else{
					throw(new Exception("CPF inválido!"));
				}//else
    		}//if strlen 
			else{
				throw(new Exception("CPF inválido!"));
			}//else
			return true;
  		}//else do começo
	}//validarCpf

	static protected function validarEmail(string $p_email){
    	filter_var($p_email, FILTER_SANITIZE_EMAIL);
    
    	if (filter_var($p_email, FILTER_VALIDATE_EMAIL)){
      		return true;
      	} else {
          	throw(new Exception('Este não é um e-mail válido. Por favor, verifique e tente novamente!'));
        }//else
  	}//validarEmail

	static protected function validarDataNasc(DateTime $p_dataNasc) {
    	$dataAtual = new DateTime();
    	if($p_dataNasc > $dataAtual) {
      		throw(new Exception("Data de nascimento inválida!"));
    	}
		return true;
  	}//validarDataNasc

}//class