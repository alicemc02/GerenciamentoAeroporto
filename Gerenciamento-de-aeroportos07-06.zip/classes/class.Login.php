<?php

  include_once("../global.php");

  class Login{//quem fez?
    private static $usuarios = array(
    	"admin" => array(
        "senha" => "admin",
        "logado" => false
      	)
	);
			  
	static public function getFilename(){
    	return "Login.txt";
   	}//getFilename
			  
	public function __construct(){}
			  
	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set
			  
    public static function cadastraUsuario(string $p_usuario, string $p_senha){
      self::$usuarios[$p_usuario] = array(
          "senha" => $p_senha,
          "logado" => false
        );
    }//cadastrarUsuario

    public static function fazLoginAdmin (string $p_usuario, string $p_senha){
    	echo "Realizando login para o usuário: $p_usuario. Por favor, aguarde!";
      	echo "\n";
      	if (array_key_exists($p_usuario, self::$usuarios) && self::$usuarios[$p_usuario]["senha"] == $p_senha) {
        // Usuário existe e a senha é válida
        	self::$usuarios[$p_usuario]["logado"] = true;
        	echo "Login bem-sucedido para o usuário $p_usuario.";
        	echo "\n";
      	} else {
      	// Usuário não existe ou a senha é inválida
      	echo "Usuário ou senha inválidos.";
      	}
    }//fazerLoginAdmin

    public static function checaLogin(){
      	if (!(self::$usuarios["admin"]["logado"] == true)){
          	echo "Ação não permitida! Por favor, insira login e senha para continuar.";
          	echo "\n";
          	return(false);
        	} else {
      	return(true);
      }//else
    }//checaLogin 
  
}//class