<?php
  enum TipoSigla {
    case PT;
    case PR;
    case PP;
    case PS;
  }
?>