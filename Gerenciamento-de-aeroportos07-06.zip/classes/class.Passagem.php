<?php

include_once("../global.php");
include_once("StatusPassageiro.php");

class Passagem extends persist{
  	private float $precoPassagem;
  	private string $assentoReservado;
  	private DateTime $dataCompra;
	
	private Viagem $viagem;
	private Passageiro $passageiro;
	private StatusPassageiro $statusPassageiro;
	
	private $bagagem = array(
    	1 => 0.0,
      	2 => 0.0,
      	3 => 0.0,
    );

  private $cartaoEmbarque = array(
    "NomePassageiro" => "",
    "SobrenomePassageiro" => "",
    "Origem" => "",
    "Destino" => "",
    "Data" => "",
    "HoraEmbarque" => "",
    "HoraPartida" => "",
    "NumeroAssento" => ""
  );
	
    //**********###############**********//
    //##########Class functions##########//
    //**********###############**********//
    
	static public function getFilename(){
    	return "Passagem.txt";
   	}//getFilename
	
  	public function __construct(array $p_viagemOrigem, Passageiro $p_passageiro){
      if (!(Login::checaLogin())) return;
		$this->viagemOrigem = $p_viagemOrigem;     
    	$this->assentoReservado = $p_assentoReservado;
    	$this->dataCompra = $p_dataCompra;   
		$this->passageiro = $p_passageiro;
  	}//construct

	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set
	
  	public function setBagagem(float $p_bagagem1, float $p_bagagem2, float $p_bagagem3){
		$testaBagagem1 = ($p_bagagem1 >= 0) && ($p_bagagem1 <= 23);
		$testaBagagem2 = ($p_bagagem2 >= 0) && ($p_bagagem2 <= 23);
		$testaBagagem3 = ($p_bagagem3 >= 0) && ($p_bagagem3 <= 23);
    	if($testaBagagem1 && $testaBagagem2 && $testaBagagem3){    //testa se as bagagens tem 23kg ou menos
      		$this->bagagem[1] = $p_bagagem1;
      		$this->bagagem[2] = $p_bagagem2;
      		$this->bagagem[3] = $p_bagagem3;
    	}else{
      		throw(new Exception('O peso das bagagens devem ser iguais ou inferiores a 23kg. Por favor, revise a carga'));
    	}//else
  	}//setBagagem
	
	static public function comprarPassagem(string $nomeViajante, string $sobrenomeViajante, string $origem, string $destino, datetime $data){
		//$passagem = new Passagem(Viagem::pesquisarViagem($data))

		$viagens = Viagem::pesquisarViagem($origem, $destino, $data, 1);
		$passageiro = Passageiro::pesquisarPassageiro($nomeViajante, $sobrenomeViajante);
		$passagem = new Passagem($viagens, $passageiro);//problema aqui: escolher a viagem e olhar a conexao
		
  	}//comprarPassagem

  	public function cancelarPassagem(Passagem $p_passagem){
    	$p_passagem->get("viagemOrigem")->setAssentoFalse($this->assentoReservado());//coloca 'false' no assento reservado previamente na Viagem
    	unset($p_passagem);
  	}//cancelarPassagem
    public function alterarPassagem(){}
	
  	public function fazerCheckin(Datetime $p_dat){
    	$tempo= new DateTime();
    	$interval = date_diff($tempo, $p_dat);
    	$interval = $interval->format('%R%a');
    	$interval2 = date_diff($tempo, $p_dat);
    	$interval2 = $interval2->format('%R%i');
    	$itv = intval( $interval );
    	$itv2 = intval( $interval2 );
    	if($itv < 30 || $itv2 < 30){}else{}
  	}//fazerCheckin

    public function createCartaoEmbarque(string $p_nome, string $p_sobrenome, string $p_origem, string $p_destino, datetime $p_data, datetime $p_embarque, datetime $p_partida, float $p_assento){

      $cartaoEmbarque["NomePassageiro"] = $p_nome;
      $cartaoEmbarque["SobreomePassageiro"] = $p_sobrenome;
      $cartaoEmbarque["Origem"] = $p_origem;
      $cartaoEmbarque["Destino"] = $p_destino;
      $cartaoEmbarque["Data"] = $p_data;
      $cartaoEmbarque["HoraEmbarque"] = $p_embarque;
      $cartaoEmbarque["HoraPartida"] = $p_partida;
      $cartaoEmbarque["NumeroAssento"] = $p_assento;      
    }//construct
	
}//class