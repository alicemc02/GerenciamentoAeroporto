<?php
include_once("../global.php");

class Rota extends persist {
  	private $enderecosVisitados = array();//string

	static public function getFilename(){
    	return "Rota.txt";
   	}//getFilename
	
  	public function __construct(string $p_enderecos){}//construct
	
	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set
	
  	public function calcularDistancia(float $lat1, float $long1, float $lat2, float $long2) {
    	# implementar com API do Google futuramente
    	$lat = deg2rad($lat2-$lat1);
    	$long = deg2rad($long2-$long1);
    	$t = sin($lat/2) * sin($lat/2) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *sin($long/2) * sin($long/2);
    	$l = 2 * atan2(sqrt($t), sqrt(1-$t));
    	$distancia = 6371 * $l;
    
    	return $distancia;
	}//calcularDistancia
	
  	public function calcularTempo(float $distancia, int $velMaxima){
    	$tempo;
    	$i_tempo = $distancia/$velMaxima;
    	if(is_float($velMaxima)){
      		$tempo = mktime($velMaxima/10, $velMaxima%10, 0);  
    	} else{
      		$tempo = mktime($velMaxima, 0, 0);  
    	}//else
    	return $tempo;
  }//calcularTempo
	
  	public function converterEndereco(int $cep) {
    	# converter em lat - long
    	# 19.8730565,-43.9736031
    	# 09838 681660
    	# 3570 0002
                    
    	$lat = rand(-900000000, 900000000);
    	$long = rand(-1800000000, 1800000000); 
    
    	$coordenada;
	    $virgula = ' , ';

    	$lat = ($lat/100000)*($cep/1000);
    	$long = ($long/1000000)*($cep%1000);
    
    	while(mod($lat) > 90) {
      		$lat = $lat/2;
    	}//while
    	while(mod($long) > 180) {
      		$long = $long/2;
    	}//while

    	$coordenada = "{$lat}{$virgula}{$long}";
    	return $coordenada;
  	}//converterEndereco

}//class