<?php
  include_once("../global.php");  

class Viagem extends persist{
    private DateTime $dataViagem;
    private DateTime $horaPartida;
    private DateTime $horaChegada;
    
	private int $pontuacaoConcedida;
	 
	private Aeronave $aeronave;
	private Voo $voo;
	private $tripulacao;// array de tripulantes
	private $viajantes;//array de passagens
	
	private $assentos;//array de string e bool
	private float $multa;
	
	//**********###############**********
    //##########Class functions##########
    //**********###############**********
      
	static public function getFilename(){
      	return "Viagem.txt";
    }//getFilename
        
    public function __construct(DateTime $p_dataViagem, DateTime $p_horaPartida, DateTime $p_horaChegada, Aeronave $p_aeronave, Voo $p_voo){
        if (!(Login::checaLogin())) return;
		$this->tripulacao = array();
		$this->assentos = array();
		$this->viajantes = array();
		
        $this->dataViagem = $p_dataViagem;
        $this->horaPartida = $p_horaPartida;
        $this->horaChegada = $p_horaChegada;
        $this->aeronave = $p_aeronave;
		$this->voo = $p_voo;
    }//construct
	
	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set
	  
	public function setAssentos(string $novoAssento, bool $ocupado){
		$this->assentos[$novoAssento] = $ocupado;
	}//setAssentos
	  
	public function gerarAssentos(int $numAssentos){
		$nAssentos = numAssentos;
    	$posicaoBanco = 1;
    	$letra = 0;
    	$momento = 2;
        for($x=1;$x<=$nAssentos;$x+=1,$momento--,$posicaoBanco++){
          	$banco = chr($letra+65) . $posicaoBanco ;
          	array_push($assentos,$banco);
          	if($momento>0){}//if
          	else{
			  	$momento=3;$letra++;$posicaoBanco=0;
		  	}//else
		}//for	
	}//gerarAssentos
	  
    public function fazerEmbarque(Aeronave $p_aeronave, Passagem $p_passagem){
      	if($this->assentos[$p_passagem->get("assentoReservado")]){
        	array_push($this->tripulacao, $p_passagem->get("passageiro"));
      	}//if
    }//fazerEmbarque

    public function setAssentoFalse(string $p_assentoCancelado){ //método utilizado APENAS pela classe Passagem durante cancelamento
      $this->assentos[$p_assentoCancelado] = false;                                                         
	}//setAssentoFalse

    public function reservarAssento(string $lugar){
    	if($this->assentos[$lugar] == false){
      		$this->assentos[$lugar] = true;
		}//if
    	else{
    		throw(new Exception('O lugar já está reservado, escolha outro lugar.'));
		}//else
	}//reservarAssento

	static function pesquisarViagemData(DateTime $data){
  		$save= Viagem::getRecords();
		$viagensCompativeis = array(); 
  		for($i = 0; $i < sizeof($save); $i++){
    		$recebe_data = save[$i]->get("dataViagem");
    		if($recebe_data == $data){
      			$viagensCompativeis = save[$i];
    		}//if
  		}//for
		return $viagensCompativeis;
	}//pesquisarViagemData

    static function pesquisarViagemVoo(Voo $voo){
  		$save = Viagem::getRecords();
		$viagensCompativeis = array();
  		for($i = 0; $i < sizeof($save); $i++){
    		$recebe_voo = save[$i]->get("voo")->get("codigoVoo");
    		if($recebe_voo == $voo->get("codigoVoo")){
      			$viagensCompativeis = save[$i];
    		}//if
  		}//for
		return $viagensCompativeis;
	}//pesquisarViagemVoo

	static public function pesquisarViagem(string $origem, string $destino, datetime $data, int $numPassageiros){
		$viagensCadastradas = Viagem::getRecordsByField($dataViagem,$data);//retorna as viagens daquela data
		$voos = Voo::pesquisarVoos($origem, $destino);//retorna os voos com esse caminho
		$compativeis = array();

		for($i = 0; $i < sizeof($viagensCadastradas); $i++){
			$totalViajantes = sizeof($viagensCadastradas[$i]->get("viajantes"));
			$capAviao = $viagensCadastradas[$i]->get("aeronave")->get("capPassageiro");
			$num = $capAviao - $totalViajantes;
				//conta os elementos do array de passagens e subtrai a capacidade do aviao - esse numero
			for($j = 0; $j < sizeof($voos); $j++){
				if(($viagensCadastradas[$i]->get("voo")->get("codigoVoo") == $voos[$j]->get("codigoVoo")) && $num >= $numPassageiros){
					$compativeis = $viagensCadastradas[$i];
				}//if
			}//j
		}//i
		return $compativeis;
	}//pesquisarViagem

    public function pontuarPassageiro(){//for( $i = 0; $i <= sizeof($save); $i++){ #PERCORRENDO O ARRAY.
    	for($i = 0; $i <= sizeof($this->viajantes); $i++){
    		if($this->viajantes[$i]->get("statusPassageiro") == StatusPassageiro::EMBREALIZADO){
          		$this->viajantes[$i]->get("passageiro")->setPontuacaoVigente($this->viajantes[$i]->get("passageiro")->get("pontuacaoVigente") + $this->pontuacaoConcedida);
        	}//if
      	}//for
    }//pontuarPassageiro

    public function calcularMulta(float $p_multa, Passageiro $p_passageiro){
      	/* 
      	//  Não é possível esta implementação, afinal a única forma de verificar 
      	//  se um passageiro é vip, seria se todos os passageiros fossem vip, 
      	//  porem alguns com benefício e outros sem, logo aquele que não tivesse, seria passageiro comum
      	if(){
        	this->$multa = $p_multa;  
      	} else {
        	this->$multa = 0.0;  
      	}
      	*/
      	$this->multa = $p_multa;  
    }//calcularMulta
	
}//clas