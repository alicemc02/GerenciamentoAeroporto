 <?php
  include_once("../global.php");
  class CompanhiaAerea extends persist{
    private string $nome;
    private string $codCompanhia;
    private string $razSocial;
    private string $siglaComp;
	
	private int $cnpj;
    private float $precoBagagem;

    //**********###############**********
    //##########Class functions##########
    //**********###############**********
    
	static public function getFilename(){
    	return "CompanhiaAerea.txt";
   	}//getFilename
	  
    public function __construct(string $p_nome, string $p_codCompanhia, string $p_razSocial, int $p_cnpj, string $p_siglaComp, float $p_precoBagagem){
      if (!(Login::checaLogin())) return;
      $this->nome = $p_nome;
      $this->codCompanhia = $p_codCompanhia;
      $this->razSocial = $p_razSocial;
      $this->cnpj = $p_cnpj;
      $this->siglaComp = $p_siglaComp;
      $this->precoBagagem = $p_precoBagagem;
    }//construct

	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set
	  
}//class