<?php
include_once("../global.php");

class Veiculo extends persist {
  	private int $capVeiculo;
  	private Rota $rotaAtendida;
  	private Viagem $viagemAtendida;
  	private int $numeroVeiculo;
  	private float $velocidadeMedia;
  	private $horarioEmbarque = array(); //<string, Datetime>
	//**********###############**********//
    //##########Class functions##########//
    //**********###############**********//
    
	static public function getFilename(){
    	return "Veiculo.txt";
   	}//getFilename
	
  	public function __construct(int $p_capVeiculo, int $p_numeroVeiculo) {
    	if (!(Login::checaLogin())) return;
    	$this->capVeiculo = $p_capVeiculo;
    	$this->numeroVeiculo = $p_numeroVeiculo;    
  	}//construct
	
	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set
	
  	public function adicionarHorarioEmbarque(Datetime $horario) {
    	$this->horarioEmbarque[] = $horario;
  	}//adicionarHorarioEmbarque
	
}//class