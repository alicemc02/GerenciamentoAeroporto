<?php

  include_once("../global.php");

  Usuario::fazLoginAdmin ("admin", "admin");

//$data = new DateTime('2023/06/07');
//Passagem::comprarPassagem("Marcela Melissa", "Tânia Fernandes", "CNF", "GUA", $data)
/*$voo = Viagem::pesquisarViagem("CNF", "GUA", $data, 1);
print(sizeof($voo));
//var_dump($voo)
//
*/
$viagens = Viagem::getRecords();
$veiculo = Veiculo::getRecords();
$trip = Tripulante::getRecords();
$tripulacao = array();
for($i = 0; $i<5; $i++){
	$tripulacao[$i] = $trip[$i];
}
//var_dump($tripulacao);
$viagens[0]->set("tripulacao", $tripulacao);
//var_dump($viagens[0]);
$veiculo[0]->set("viagemAtendida",$viagens[0]);
//var_dump($veiculo);
$cood = array();
for($i = 0; $i< 5; $i++){
	$trip = $veiculo[0]->get("viagemAtendida")->get("tripulacao");
	$cood[$i] = Coordenadas::converterEndereco($trip[$i]->get("cep"));
}
//$pass = Passageiro::pesquisarPassageiro("Marcela Melissa", "Tânia Fernandes");
//var_dump($pass);
//var_dump($cood);
/*$veiculo[0]->construirRota();
$viagem = $veiculo[0]->get("viagemAtendida");
$veiculo[0]->get("rotaAtendida")->calcularHorarioEmbarque($viagem->get("horaPartida"), $viagem->get("voo")->get("aeroportoPartida"), $veiculo[0]->get("velocidadeMedia"));
*/
//var_dump($veiculo[0]->get("rotaAtendida")->get("horarioEmbarque"));
//var_dump($veiculo[0]);
//$cod = $veiculo[0]->get("rotaAtendida")->get("enderecosVisitados");
//$dist = Coordenadas::calcularDistancia($cod[0], $cod[1]);
//print($dist);
//$t = $veiculo[0]->calcularTempo(145);
//print($t);
//$horaFinal = new DateTime();
//$horaFinal->sub(new DateInterval('PT90M'));
//var_dump($horaFinal);

?>