<?php
include_once("../global.php");

class Veiculo extends persist {
  	private int $capVeiculo;
	private int $numeroVeiculo;
	private float $velocidadeMedia;//em Km/h
  	
	private Rota $rotaAtendida;
  	private Viagem $viagemAtendida;
  
	//**********###############**********//
    //##########Class functions##########//
    //**********###############**********//
    
	static public function getFilename(){
    	return "Veiculo.txt";
   	}//getFilename
	
  	public function __construct(int $p_capVeiculo, int $p_numeroVeiculo, float $p_velMedia) {
    	if (!(Usuario::checaLogin())) return;
    	$this->capVeiculo = $p_capVeiculo;
    	$this->numeroVeiculo = $p_numeroVeiculo; 
		$this->velocidadeMedia = $p_velMedia;
  	}//construct
	
	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set

	public function construirRota(){
		$tripulacao = $this->get("viagemAtendida")->get("tripulacao");
		$coordenadas = array();
		for($i = 0; $i<sizeof($tripulacao); $i++){
			$coordenadas[$i] = Coordenadas::converterEndereco($tripulacao[$i]->get("cep"));
		}//for
		$this->rotaAtendida = new Rota($coordenadas);
	}//construirRota
	
}//class