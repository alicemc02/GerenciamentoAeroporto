<?php

  include_once("../global.php"); 

  class Conexao extends persist{
    private Voo $vooPartida;
    private Voo $vooChegada;

	private $viagensPartida;
	private $viagensChegada;

    //**********###############**********
    //##########Class functions##########
    //**********###############**********
    
	static public function getFilename(){
    	return "Conexao.txt";
   	}//getFilename
     
	public function __construct(Voo $p_vooPartida, Voo $p_vooChegada){
      	if (!(Usuario::checaLogin())) return;
    	$this->vooPartida = $p_vooPartida;
		$this->vooChegada = $p_vooChegada;
		$viagensPartida = array();
		$visgensChegada = array();
  	}//construct

	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set
	  
}//class