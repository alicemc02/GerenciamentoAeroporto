<?php

include_once("../global.php");

class ProgramaMilhagem extends persist{
	private string $nomePrograma;
	private int $numeroRegistro;
	private $categorias;
	private CompanhiaAerea $companhiaAerea;

	//**********###############**********//
    //##########Class functions##########//
    //**********###############**********//
    
	static public function getFilename(){
    	return "ProgramaMilhagem.txt";
   	}//getFilename
	
	public function __construct(string $p_nomePrograma, int $p_numRegistro, CompanhiaAerea $p_compAerea) {
      if (!(Usuario::checaLogin())) return;
    	$this->nomePrograma = $p_nomePrograma;
    	$this->numeroRegistro = $p_numRegistro; 
		$this->companhiaAerea = $p_compAerea;
		$this->categorias = array();
  	}//construct
	
	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set
	
  	static public function fazerUpgrade(PassageiroVip $passageiro){
    	$pontuacao = $passageiro->get("pontuacaoVigente");
		$programa = $passageiro->get("programaFavorito");
		$categorias = $programa->get("categorias");
		$categoriaAtual = $pontuacao;
    	for($i = 0; $i < sizeof($categorias); $i++){
      		if($pontuacao >= $categorias[$i]->get("pontuacaoMinima")){
				if($categorias[$i]->get("pontuacaoMinima") >= $categoriaAtual){
					$passageiro->set("categoriaVigente", $categorias[$i]);
					$categoriaAtual = $categorias[$i]->get("pontuacaoMinima");
				}//if
      		}//if
    	}//for  
  	}//fazerUpgrade 
  
  	static public function fazerDowngrade(PassageiroVip $passageiro){
    	$pontuacao = $passageiro->get("pontuacaoVigente");
		$programa = $passageiro->get("programaFavorito");
		$categorias = $programa->get("categorias");
    	for($i = sizeof($categorias)-1; $i >= 0; $i--){
      		if($pontuacao >= $categorias[$i]->get("pontuacaoMinima")){
        		$passageiro->set("categoriaVigente", $categorias[$i]);
      		}//if
    	}//for
	}//fazerDowngrade
	
}//class