<?php
  	include_once("../global.php");
	include_once("TipoTripulante.php");
	class Tripulante extends Pessoa{
		private int $cht;
		private int $numeroEnd;
		private int $cep;

		private string $logradouro;
		private string $bairro;
		private string $cidade;
		private string $estado;
    	private string $pais;
		
		private TipoTripulante $tipoTripulante;
		
		private CompanhiaAerea $companhiaAerea;
		private Aeroporto $aeroportoBase;
		
		//**********###############**********//
    	//##########Class functions##########//
    	//**********###############**********//
    
		static public function getFilename(){
    		return "Tripulante.txt";
   		}//getFilename
		
		public function __construct(string $p_nome, string $p_sobrenome, string $p_documento, int $p_cpf, string $p_nacionalidade, DateTime $p_dataNasc, string $p_email, int $p_cht, int $p_numeroEnd, int $p_cep, string $p_logradouro, string $p_bairro, string $p_cidade, string $p_estado, string $p_pais, TipoTripulante $p_tipo, CompanhiaAerea $p_compAerea, Aeroporto $p_base) {
      		if (!(Usuario::checaLogin())) return;
      		parent::__construct($p_nome, $p_sobrenome, $p_documento, $p_cpf, $p_nacionalidade, $p_dataNasc, $p_email);

			$this->cht = $p_cht;
			$this->numeroEnd = $p_numeroEnd;
			$this->cep = $p_cep;
			$this->logradouro = $p_logradouro;
			$this->bairro = $p_bairro;
			$this->cidade = $p_cidade;
			$this->estado = $p_estado;
			$this->pais = $p_pais;
			$this->tipoTripulante = $p_tipo;
			$this->companhiaAerea = $p_compAerea;
			$this->aeroportoBase = $p_base;
			
    	}//construct

		public function get(string $nomeAtributo){
			return $this->$nomeAtributo;
		}//get
		public function set(string $nomeAtributo, $valorAtributo){
			$this->$nomeAtributo = $valorAtributo;
		}//set
		

		public function getEndereco(){
      		# Rua – Street (St)
      		# Cidade – City
      		# Estado – State
      		# CEP (Código Postal) – Zip Cod
      		# País – Country      
			$endereco = $this->logradouro + $this->numeroEnd + $this->bairro + $this->cidade + $this->estado + $this->cep + $this->pais;
			return $endereco;
		}//getEndereco
		
	}//class