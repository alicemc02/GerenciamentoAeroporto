<?php
include_once("../global.php");
define('ANTECEDENCIA_CHEGADA',90);//minutos

class Rota extends persist {
  	private $enderecosVisitados;//coordenadas
 	private $horarioEmbarque;
	
	static public function getFilename(){
    	return "Rota.txt";
   	}//getFilename
	
  	public function __construct($p_coordenadas){
		if (!(Usuario::checaLogin())) return;
		$this->enderecosVisitados = $p_coordenadas;
	}//construct
	
	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set

	//calcula o tempo em min
	public function calcularTempo(float $distancia, float $velocidade){
    	$h_tempo = $distancia/$velocidade;
		$tempo = $h_tempo * 60;
    	return $tempo;
  	}//calcularTempo
	
	public function calcularHorarioEmbarque(Datetime $horarioPartida, Aeroporto $base, float $velocidade){
		$horaChegada = clone $horarioPartida;
		$horaChegada->sub(new DateInterval('PT'.ANTECEDENCIA_CHEGADA.'M'));

		$coodBase = $base->get("coordenadas");
		$enderecos = $this->enderecosVisitados;
		$distancias = array();
		$tempos = array();
		$horaEmbarque = array();
		
		for($i = 0; $i < sizeof($enderecos); $i++){
			$distancias[$i] = Coordenadas::calcularDistancia($enderecos[$i], $coodBase);
		}//for que calcula as distancias
		for($i = 0; $i < sizeof($distancias); $i++){
			$tempos[$i] = $this->calcularTempo($distancias[$i], $velocidade);
		}//for que calcula os tempos
		for($i = 0; $i < sizeof($tempos); $i++){
			$hora = clone $horaChegada;
			$horaEmbarque[$i] = $hora->sub(new DateInterval('PT'.round($tempos[$i]).'M'));
		}//for que calcula o horario de embarque
		$this->horarioEmbarque = $horaEmbarque;
  	}//calcularHorarioEmbarque
	
}//class