<?php

  include_once("../global.php");
$data1 = new DateTime('2023/06/09');
$data2 = new DateTime('2023/06/07');
$dif = date_diff($data1, $data2);
var_dump($dif);
echo $dif->format('%i horas');

/*
  Usuario::fazLoginAdmin ("admin", "admin");

$companhiaLatam= new CompanhiaAerea("Latam", "001", "Latam Airlines do Brasil S.A.","81435185000169", "LA", 20.00);
  $companhiaAzul= new CompanhiaAerea("Azul", "002", "Azul Linhas Aéreas Brasileiras S.A.","23654444325698", "AD", 25.00);

$newPrograma1 = new ProgramaMilhagem("TudoAzul", 123456, $companhiaAzul);
$newPrograma1->save();

$newPrograma2 = new ProgramaMilhagem("Latido", 789000, $companhiaLatam);
$newPrograma2->save();


$data = new DateTime('2023/06/07');
//
$viaj = Passageiro::pesquisarPassageiro("Marcela Melissa", "Tânia Fernandes");
$viajVip = PassageiroVip::pesquisarPassageiro("Ruan", "Yago da Cunha");
$viajVip->set("programaFavorito", $newPrograma1);

//var_dump($viajVip);
$voo = Viagem::pesquisarViagem("CNF", "GUA", $data, 1);
$voo[0]->set("multa", 650);
$voo[0]->save();
$voo[0]->get("voo")->set("tarifa", 1300);
$voo[0]->save();
$voo[0]->get("voo")->get("companhiaAerea")->set("precoBagagem", 300);
$voo[0]->save();
$pass = Passagem::comprarPassagem("Marcela Melissa", "Tânia Fernandes", "CNF", "GUA", $data);
$pass->set("assentoReservado", "55A");
$pass->setBagagem(12, 20, 16);
$mul = $voo[0]->calcularRessarcimento($viajVip,false);
$tot = $pass->calcularTotal();
var_dump($tot);
//$pass->cancelarPassagem();
//var_dump($pass);
//var_dump($mul);
//print(sizeof($voo));
//var_dump($voo)
//
/*
$viagens = Viagem::getRecords();
$veiculo = Veiculo::getRecords();
$trip = Tripulante::getRecords();
$tripulacao = array();
for($i = 0; $i<5; $i++){
	$tripulacao[$i] = $trip[$i];
}
//var_dump($tripulacao);
$viagens[0]->set("tripulacao", $tripulacao);
//var_dump($viagens[0]);
$veiculo[0]->set("viagemAtendida",$viagens[0]);
//var_dump($veiculo);
$cood = array();
for($i = 0; $i< 5; $i++){
	$trip = $veiculo[0]->get("viagemAtendida")->get("tripulacao");
	$cood[$i] = Coordenadas::converterEndereco($trip[$i]->get("cep"));
}
//$pass = Passageiro::pesquisarPassageiro("Marcela Melissa", "Tânia Fernandes");
//var_dump($pass);
//var_dump($cood);
/*$veiculo[0]->construirRota();
$viagem = $veiculo[0]->get("viagemAtendida");
$veiculo[0]->get("rotaAtendida")->calcularHorarioEmbarque($viagem->get("horaPartida"), $viagem->get("voo")->get("aeroportoPartida"), $veiculo[0]->get("velocidadeMedia"));
*/
//var_dump($veiculo[0]->get("rotaAtendida")->get("horarioEmbarque"));
//var_dump($veiculo[0]);
//$cod = $veiculo[0]->get("rotaAtendida")->get("enderecosVisitados");
//$dist = Coordenadas::calcularDistancia($cod[0], $cod[1]);
//print($dist);
//$t = $veiculo[0]->calcularTempo(145);
//print($t);
//$horaFinal = new DateTime();
//$horaFinal->sub(new DateInterval('PT90M'));
//var_dump($horaFinal);

?>