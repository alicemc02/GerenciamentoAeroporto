<?php
// ==================================================================
//Inclusão das classes necessárias para testar a classe viagem.


  include_once("../global.php");
  include_once("../classes/class.Voo.php"); 
  include_once("../classes/class.Viagem.php"); 
// ====================================================================




  $companhiaTAM = new CompanhiaAerea("TAM", "GUO", "TAM DISTRB. LTDA" ,"81435185000169", "TM", 23.00 );  

  $new_aeronave = new Aeronave("Boeing", "747", $companhiaTAM);




// ============================================================

// Criação de um objeto do tipo DateTime que vai armazenar a data, a hora de partida e a hora de chegada.
  $data = new DateTime();
  $data->setDate(2023, rand(1, 12), rand(1, 28));
  $data->setTime(rand(0, 23), rand(0, 59), rand(0, 59));
  
  $partida = new DateTime();
  $partida->setTime(rand(0, 23), rand(0, 59), rand(0, 59));
  
  $chegada = new DateTime();
  $chegada->setTime(rand(0, 23), rand(0, 59), rand(0, 59));

// ==============================================================


  $new_viagem = new Viagem($data, $partida, $chegada, $new_aeronave);

  print_r($new_viagem);
?>