 <?php
  include_once("../global.php");
  class CartaoEmbarque extends persist{
    private string $nomePassageiro;
    private string $sobrenomePassageiro;
    private string $aeroportoOrigem;
    private string $aeroportoDestino;
    private datetime $horarioEmbarque;
    private datetime $horarioPartida;
    private string $assento;

    //**********###############**********
    //##########Class functions##########
    //**********###############**********
    
	static public function getFilename(){
    	return "CartaoEmbarque.txt";
   	}//getFilename
	  
    public function __construct(string $p_nome, string $p_sobrenome, string $p_aeroportoOrigem, string $p_aeroportoDestino, datetime $p_horaEmbarque, datetime $p_horaPartida, string $p_assento){
      if (!(Usuario::checaLogin())) return;
      $this->nomePassageiro = $p_nome;
      $this->sobrenomePassageiro = $p_sobrenome;
      $this->aeroportoOrigem = $p_aeroportoOrigem;
      $this->aeroportoDestino = $p_aeroportoDestino;
      $this->horarioEmbarque = $p_horaEmbarque;
      $this->aeroportoPartida = $p_horaPartida;
      $this->assento = $p_assento;
    }//construct

	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set
	  
}//class
