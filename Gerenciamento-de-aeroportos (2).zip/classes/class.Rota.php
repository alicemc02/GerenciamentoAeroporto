<?php
include_once("../global.php");

class Rota extends persist {
  	private $enderecosVisitados;//coordenadas
 	private $horarioEmbarque;
	
	static public function getFilename(){
    	return "Rota.txt";
   	}//getFilename
	
  	public function __construct($p_coordenadas){
		if (!(Usuario::checaLogin())) return;
		$this->enderecosVisitados = $p_coordenadas;
	}//construct
	
	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set

	//calcula o tempo em min
	public function calcularTempo(float $distancia, float $velocidade){
    	$h_tempo = $distancia/$velocidade;
		$tempo = $h_tempo * 60;
    	return $tempo;
  	}//calcularTempo
	
	public function calcularHorarioEmbarque(Datetime $horarioPartida, Aeroporto $base, float $velocidade){
		$horaChegada = $horarioPartida;
		$horaChegada->sub(new DateInterval('PT90M'));//subtrai 90 minutos da hora da viagem, para saber o horario de chegada

		$coodBase = $base->get("coordenadas");
		$enderecos = $this->enderecosVisitados;
		$distancias = array();
		$tempos = array();
		$horaEmbarque = array();
		
		for($i = 0; $i < sizeof($enderecos); $i++){
			$distancias[$i] = Coordenadas::calcularDistancia($enderecos[$i], $coodBase);
		}//for que calcula as distancias
		//var_dump($distancias);
		for($i = 0; $i < sizeof($distancias); $i++){
			$tempos[$i] = $this->calcularTempo($distancias[$i], $velocidade);
		}//for que calcula os tempos
		//var_dump($tempos);
		for($i = 0; $i < sizeof($tempos); $i++){
			///var_dump($horaChegada->sub(new DateInterval('PT'.round($tempos[$i]).'M')));
			
			$horaEmbarque[$i] = $horaChegada->sub(new DateInterval('PT'.round($tempos[$i]).'M'));
			var_dump($horaEmbarque[$i]);
		}//for que calcula o horario de embarque
		var_dump($horaEmbarque);
		$this->horarioEmbarque = $horaEmbarque;
  	}//calcularHorarioEmbarque
	
}//class