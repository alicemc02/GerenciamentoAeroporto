<?php
  enum TipoTripulante {
    case PILOTO;
    case COMISSARIO;
  }
?>