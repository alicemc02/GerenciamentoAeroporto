<?php
	include_once("../global.php");

class CategoriaPrograma extends persist{
	private string $nomeCategoria;
	private int $pontuacaoMinima;

	//**********###############**********
    //##########Class functions##########
    //**********###############**********

	static public function getFilename(){
    	return "CategoriaPrograma.txt";
   	}//getFilename

	public function __construct(string $p_nome, int $p_pontMinima){
    if (!(Login::checaLogin())) return;
		$this->nomeCategoria = $p_nome;
		$this->pontuacaoMinima = $p_pontMinima;
	}//construct

	public function get(string $nomeAtributo){
		return $this->$nomeAtributo;
	}//get
	public function set(string $nomeAtributo, $valorAtributo){
		$this->$nomeAtributo = $valorAtributo;
	}//set
	
}//class